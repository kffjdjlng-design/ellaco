
export type ItemType = 'folder' | 'document' | 'character' | 'location' | 'item' | 'research' | 'link' | 'front-matter' | 'back-matter';

export type Language = 'Turkish' | 'Azerbaijani' | 'English' | 'French' | 'Spanish' | 'Italian' | 'Portuguese';

export type UITheme = 'light' | 'dark' | 'sepia' | 'solarized';

export interface Snapshot {
  id: string;
  itemId: string;
  title: string;
  content: string;
  timestamp: number;
}

export interface Attachment {
  id: string;
  name: string;
  type: 'image' | 'pdf' | 'note';
  url: string;
}

export interface Storyline {
  id: string;
  name: string;
  color: string;
}

export interface LogEntry {
  id: string;
  timestamp: number;
  wordsAdded: number;
  sessionMinutes: number;
  note?: string;
}

export interface EditorialComment {
  id: string;
  author: string;
  text: string;
  timestamp: number;
  resolved: boolean;
  selectionText?: string;
}

export interface BoardCard {
  id: string;
  title: string;
  content: string;
  color?: string;
}

export interface BoardColumn {
  id: string;
  title: string;
  cards: BoardCard[];
}

export interface Board {
  id: string;
  name: string;
  columns: BoardColumn[];
}

export interface BinderItem {
  id: string;
  title: string;
  type: ItemType;
  content: string;
  synopsis?: string;
  keywords?: string[]; 
  attachments?: Attachment[]; 
  comments?: EditorialComment[]; 
  socialStats?: {
    votes: number;
    reads: number;
    commentsCount: number;
  };
  yWriterData?: {
    conflict?: string;
    outcome?: string;
    sceneGoal?: string;
    tension?: number; 
    importance?: number; 
    humor?: number; 
    quality?: number; 
    storylineId?: string;
    timeOfDay?: string;
    inStoryDay?: number;
    durationMinutes?: number;
    rating?: number; 
  };
  metadata?: {
    wordGoal?: number;
    status?: 'To Do' | 'First Draft' | 'Revised' | 'Final';
    label?: 'Chapter' | 'Scene' | 'Note' | 'Research';
    lastEdited?: number;
    linkedCharacters?: string[]; 
    linkedLocations?: string[];  
    linkedItems?: string[]; 
    url?: string; 
  };
  children?: BinderItem[];
}

export type BookTheme = 'Classic' | 'Romance' | 'Thriller' | 'Modern' | 'Sci-Fi' | 'Academic';

export interface WorldMapPin {
  id: string;
  x: number;
  y: number;
  title: string;
  description: string;
  linkedLocationId?: string;
}

export interface WorldMap {
  id: string;
  name: string;
  imageUrl: string;
  pins: WorldMapPin[];
}

export interface LoreEntry {
  id: string;
  category: 'History' | 'Factions' | 'Magic' | 'Technology' | 'Culture' | 'Other';
  title: string;
  content: string;
}

export interface ProjectState {
  id: string;
  name: string;
  language: Language;
  uiLanguage: Language; 
  genre?: string;
  tags?: string[];
  coverUrl?: string;
  authorName?: string;
  socialMetrics?: {
    totalVotes: number;
    totalReads: number;
    followers: number;
  };
  binder: BinderItem[];
  boards: Board[];
  snapshots: Snapshot[];
  characters: CharacterProfile[];
  locations: LocationProfile[];
  items: StoryItem[]; 
  storylines: Storyline[]; 
  writingLog: LogEntry[]; 
  worldBuilding: {
    lore: LoreEntry[];
    maps: WorldMap[];
  };
  goals: {
    dailyWordGoal: number;
    totalWordGoal: number;
    deadline?: string; 
  };
  settings: {
    typewriterMode: boolean;
    markupMode: boolean;
    bookTheme: BookTheme;
    uiTheme: UITheme;
    pageMargins: number;
    lineSpacing: number;
    pageOrientation: 'portrait' | 'landscape';
  };
}

export interface CharacterProfile {
  id: string;
  name: string;
  role: string;
  traits: string[];
  goals: string;
  description: string;
  imageUrl?: string;
}

export interface LocationProfile {
  id: string;
  name: string;
  description: string;
  imageUrl?: string;
}

export interface StoryItem {
  id: string;
  name: string;
  description: string;
  isMacGuffin: boolean;
}

export type ViewMode = 'dashboard' | 'editor' | 'corkboard' | 'outliner' | 'split' | 'characters' | 'research' | 'compile' | 'storyboard' | 'log' | 'reader' | 'world' | 'boards' | 'templates';
