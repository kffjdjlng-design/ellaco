
import { GoogleGenAI, Type } from "@google/genai";
import { Language } from "./types";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const aiService = {
  async analyzeStyle(text: string, language: Language) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a world-class literary critic specializing in ${language}. Perform a deep style analysis on the following text. 
      IMPORTANT: All generated labels, descriptions, and suggestions MUST be in ${language}.
      Ensure the sentiment and tone reflect native linguistic nuances of ${language}.
      
      Return a JSON object with: 
      - readabilityScore (0-100)
      - sentiment (string, localized)
      - suggestions (array of strings, localized)
      - keyThemes (array of strings, localized)
      - tone (string, localized)
      
      Text: "${text}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            readabilityScore: { type: Type.NUMBER },
            sentiment: { type: Type.STRING },
            suggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
            keyThemes: { type: Type.ARRAY, items: { type: Type.STRING } },
            tone: { type: Type.STRING }
          },
          required: ["readabilityScore", "sentiment", "suggestions", "keyThemes", "tone"]
        }
      }
    });
    return JSON.parse(response.text || '{}');
  },

  async getWritingSparks(context: string, prompt: string, language: Language) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `As a creative writing assistant with perfect command of ${language}, help the author with this task.
      Context: ${context}
      User Request: ${prompt}
      
      CRITICAL: You MUST respond ONLY in ${language}. Use high-level literary vocabulary and follow standard ${language} narrative conventions.`,
    });
    return response.text || '';
  },

  async rephraseText(text: string, style: string, language: Language) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Rephrase the following ${language} text in a ${style} style. 
      Ensure you use appropriate ${language} idioms and maintain the cultural context of a native ${language} speaker.
      Text: "${text}"`,
    });
    return response.text || '';
  },

  async getProWritingReport(text: string, reportType: string, language: Language) {
    const ai = getAI();
    const prompts: Record<string, string> = {
      sticky: `Identify 'sticky sentences' in ${language} (sentences with too many glue words).`,
      overused: `Find overused ${language} words and repetitive sentence patterns common in ${language} writing.`,
      cliches: `Identify ${language} clichés, tired metaphors, and specific cultural tropes.`,
      pacing: `Analyze the narrative pacing for this ${language} text based on sentence complexity.`,
      dialogue: `Analyze ${language} dialogue for natural flow, subtext, and regional dialect accuracy if applicable.`,
      grammar: `Perform a comprehensive grammar, spelling, and punctuation check in ${language}, adhering to the latest orthographic rules.`,
      vague: `Identify vague language and weak verbs specific to ${language} linguistic habits.`
    };

    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `Report Type: ${reportType}. Language: ${language}.
      Task: ${prompts[reportType]}
      Text: "${text}"
      
      Return a JSON object with:
      - score (0-100)
      - findings (array of objects with 'original', 'issue', 'suggestion')
      - summary (string, localized)
      
      Ensure all issues and suggestions are perfectly optimized for ${language} grammar and elite literary style.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            findings: { 
              type: Type.ARRAY, 
              items: { 
                type: Type.OBJECT, 
                properties: {
                  original: { type: Type.STRING },
                  issue: { type: Type.STRING },
                  suggestion: { type: Type.STRING }
                }
              } 
            },
            summary: { type: Type.STRING }
          },
          required: ["score", "findings", "summary"]
        }
      }
    });
    return JSON.parse(response.text || '{}');
  },

  async checkPlagiarism(text: string, language: Language): Promise<{ text: string; sources: string[] }> {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Check for plagiarism for this ${language} text. 
      Identify matches on the web and provide a detailed summary in ${language}.
      
      Text: "${text}"`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const textOutput = response.text || "No scan output available.";
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const urls = chunks
      .map((chunk: any) => chunk.web?.uri)
      .filter((uri: any): uri is string => typeof uri === 'string');

    return {
      text: textOutput,
      sources: Array.from(new Set<string>(urls)),
    };
  },

  async getBetaReaderFeedback(text: string, language: Language) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `Act as a professional beta reader and literary editor in ${language}. 
      Provide a comprehensive critique in ${language} covering emotional resonance, consistency, and pacing.
      Consider the expectations of a sophisticated reader of ${language} literature.
      
      Text: "${text}"`,
    });
    return response.text || '';
  },

  async getSynonyms(word: string, language: Language) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide a detailed ${language} thesaurus entry for the word "${word}". 
      Include nuanced synonyms, antonyms, and example sentences in a high-literary ${language} style.`,
    });
    return response.text || '';
  },

  async translateText(text: string, targetLanguage: Language, sourceLanguage?: Language) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Translate this text from ${sourceLanguage || 'auto'} to ${targetLanguage}.
      CRITICAL: The output must feel like it was originally written in ${targetLanguage} by a master storyteller. 
      Maintain HTML formatting if present.
      
      Text: "${text}"`,
    });
    return response.text || '';
  },

  async generateImage(prompt: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: `High quality cinematic digital art portrait: ${prompt}`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        },
      },
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error('No image was generated');
  },

  async conductResearch(query: string, language: Language) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Conduct authoritative research on: "${query}". 
      Provide a comprehensive, scholarly, and structured report exclusively in ${language}. 
      Ensure the terminology is accurate for native ${language} academic standards.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const textOutput = response.text || "No research findings available.";
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sources = chunks
      .map((chunk: any) => ({
        title: chunk.web?.title || "Reference",
        url: chunk.web?.uri
      }))
      .filter((source: any) => source.url);

    return {
      answer: textOutput,
      sources: sources
    };
  }
};
