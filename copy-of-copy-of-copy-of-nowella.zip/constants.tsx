
import React from 'react';
import { Folder, FileText, Users, MapPin, Search, Archive, ChevronRight, ChevronDown, Layout, List, Split, Maximize2, Zap, Save, Trash2, Edit3, Settings, BarChart2, Package, Clock, Flame, Smile, Layers, History, Book, BookOpen, Heart, Eye, MessageCircle, Hash, Image as ImageIcon, Globe, Map as MapIcon, Palette, Compass, Sword, Shield, BookMarked, Sun, Moon, Coffee, Cloud, Trello, Copy } from 'lucide-react';
import { Language, UITheme } from './types';

export const ICONS = {
  folder: <Folder className="w-4 h-4" />,
  document: <FileText className="w-4 h-4" />,
  character: <Users className="w-4 h-4" />,
  location: <MapPin className="w-4 h-4" />,
  item: <Package className="w-4 h-4" />,
  research: <Search className="w-4 h-4" />,
  archive: <Archive className="w-4 h-4" />,
  chevronRight: <ChevronRight className="w-4 h-4" />,
  chevronDown: <ChevronDown className="w-4 h-4" />,
  layout: <Layout className="w-4 h-4" />,
  list: <List className="w-4 h-4" />,
  split: <Split className="w-4 h-4" />,
  maximize: <Maximize2 className="w-4 h-4" />,
  zap: <Zap className="w-4 h-4" />,
  save: <Save className="w-4 h-4" />,
  trash: <Trash2 className="w-4 h-4" />,
  edit: <Edit3 className="w-4 h-4" />,
  settings: <Settings className="w-4 h-4" />,
  stats: <BarChart2 className="w-4 h-4" />,
  time: <Clock className="w-4 h-4" />,
  tension: <Flame className="w-4 h-4" />,
  humor: <Smile className="w-4 h-4" />,
  storyboard: <Layers className="w-4 h-4" />,
  history: <History className="w-4 h-4" />,
  book: <Book className="w-4 h-4" />,
  vote: <Heart className="w-4 h-4" />,
  reads: <Eye className="w-4 h-4" />,
  comments: <MessageCircle className="w-4 h-4" />,
  tag: <Hash className="w-4 h-4" />,
  cover: <ImageIcon className="w-4 h-4" />,
  globe: <Globe className="w-4 h-4" />,
  map: <MapIcon className="w-4 h-4" />,
  palette: <Palette className="w-4 h-4" />,
  compass: <Compass className="w-4 h-4" />,
  sword: <Sword className="w-4 h-4" />,
  shield: <Shield className="w-4 h-4" />,
  lore: <BookMarked className="w-4 h-4" />,
  boards: <Trello className="w-4 h-4" />,
  templates: <Copy className="w-4 h-4" />,
  'front-matter': <Book className="w-4 h-4 text-indigo-400" />,
  'back-matter': <BookOpen className="w-4 h-4 text-emerald-400" />,
};

export const UI_THEMES: { id: UITheme; label: string; icon: React.ReactNode }[] = [
  { id: 'light', label: 'Daylight', icon: <Sun size={14} /> },
  { id: 'dark', label: 'Midnight', icon: <Moon size={14} /> },
  { id: 'sepia', label: 'Vintage', icon: <Coffee size={14} /> },
  { id: 'solarized', label: 'Zen', icon: <Cloud size={14} /> },
];

export const SUPPORTED_LANGUAGES: { name: Language; label: string; code: string }[] = [
  { name: 'English', label: 'English', code: 'en' },
  { name: 'Turkish', label: 'Türkçe', code: 'tr' },
  { name: 'Azerbaijani', label: 'Azərbaycan', code: 'az' },
  { name: 'French', label: 'Français', code: 'fr' },
  { name: 'Spanish', label: 'Español', code: 'es' },
  { name: 'Italian', label: 'Italiano', code: 'it' },
  { name: 'Portuguese', label: 'Português', code: 'pt' },
];

export const TRANSLATIONS: Record<Language, Record<string, string>> = {
  English: {
    write: 'Write', split: 'Split', board: 'Board', plot: 'Plot', outline: 'Outline', log: 'Log', cast: 'Cast', reader: 'Reader Mode',
    compile: 'Compile', typewriter: 'Typewriter', words: 'Words', progress: 'Progress', autoSaved: 'Manuscript Auto-Saved',
    inspector: 'Inspector', attachments: 'Attachments', ai: 'AI', stats: 'Stats', snapshots: 'Snapshots', lab: 'AI Writing Lab',
    sparks: 'Writing Sparks', rephrase: 'Rephrase', report: 'Pro Style Report', grammar: 'Grammar & Spell', plagiarism: 'Plagiarism Scan',
    sticky: 'Sticky Sentences', overused: 'Overused Words', cliches: 'Cliches & Tropes', pacing: 'Pacing Scan', dialogue: 'Dialogue Check',
    vague: 'Vague Language', critique: 'Virtual Beta Reader', analyze: 'Analyze Manuscript', settings: 'Book Settings', theme: 'Typesetting Theme',
    genre: 'Genre', tags: 'Tags', metadata: 'Metadata', generate: 'Generate Production File', votes: 'Votes', reads: 'Reads',
    world: 'World Hub', visualizer: 'Visualizer', uiTheme: 'Interface Theme',
    boards: 'Idea Boards', templates: 'Templates', collaboration: 'Collaboration', share: 'Share',
    generateSpark: 'Generate Spark', targetLanguage: 'Target Language', translateManuscript: 'Translate Manuscript',
    efficiencyScore: 'Efficiency Score', styleScore: 'Style Score', toneSentiment: 'Tone & Sentiment', themes: 'Themes',
    detectedSources: 'Detected Sources', part: 'Part', voteForPart: 'Vote for this part', library: 'Library', 
    readerPreview: 'Reader Preview', binderTitle: 'Manuscript Binder', findInHierarchy: 'Find in hierarchy...',
    newScene: 'New Scene', newSubSection: 'New Sub-Section', deleteEntry: 'Delete Entry', tools: 'Tools',
    reports: 'Reports', critiqueTab: 'Critique', translate: 'Translate', summoningAI: 'Summoning AI Intelligence...',
    aiIdle: 'AI Writing Lab Idle', aiIdleDesc: 'Select a tool or enter a spark prompt to enhance your manuscript.',
    sectionStrategyNode: 'Section Strategy Node', activeDraft: 'Active Draft', sectionWordCount: 'Section Word Count',
    minReadingTime: 'Min. Reading Time', narrativeObjective: 'Narrative Objective', intensityArc: 'Intensity Arc',
    sectionHealth: 'Section Health', sequenceMap: 'Sequence Map', newNarrativeScene: 'New Narrative Scene',
    filterScenes: 'Filter Scenes', viewOptions: 'View Options', sceneTitle: 'Scene Title', status: 'Status',
    conflict: 'Conflict', outcome: 'Outcome', tension: 'Tension', importance: 'Importance', humor: 'Humor',
    quality: 'Quality', timeDay: 'Time / Day', projectCastAssets: 'Project Cast & Assets', addCharacter: 'Add Character',
    addSetting: 'Add Setting', addPlotObject: 'Add Plot Object', totalManuscriptProgress: 'Total Manuscript Progress',
    deadlineInsight: 'Deadline Insight', daysLeft: 'Days Left', wordsPerDay: 'Words / Day', writingVelocity: 'Writing Velocity',
    socialMetrics: 'Social Metrics', researchIntelligence: 'Research Intelligence', initializeFramework: 'Initialize Framework',
    customArchitecture: 'Custom Architecture', workLog: 'Work Log', newSession: 'New Session', avgVelocity: 'Avg. Velocity',
    follows: 'Follows', parts: 'Parts', lore: 'Lore', maps: 'Maps', bio: 'Bio', arc: 'Arc', goal: 'Goal',
    narrative: 'Narrative', plotThread: 'Plot Thread', sessionHistory: 'Session History', writingTime: 'Writing Time',
    lifeTimeWords: 'Life-Time Words', includes: 'Includes', blueprintTitle: 'Narrative Blueprints', blueprintDesc: 'Standardized frameworks to structure your storytelling intelligence.',
    standardNovel: 'Standard Novel', heroJourney: "Hero's Journey", saveTheCat: 'Save the Cat Beats', thrillerPulse: 'Thriller Pulse', academicMaster: 'Academic Master', lifeLegacy: 'Life Legacy',
    appLanguage: 'App Language', projectLanguage: 'Work Language', startNewWork: 'Start New Work', projectTitle: 'Work Title', pickLanguage: 'Select Language',
    manuscriptBlueprint: 'Manuscript Blueprint', welcomeBack: 'Welcome Back, Author', setupMessage: 'Let us configure your workspace language preferences.',
    writing: 'Writing', exit: 'Exit'
  },
  Turkish: {
    write: 'Yaz', split: 'Böl', board: 'Pano', plot: 'Kurgu', outline: 'Taslak', log: 'Günlük', cast: 'Kadro', reader: 'Okuma Modu',
    compile: 'Derle', typewriter: 'Daktilo', words: 'Kelime', progress: 'İlerleme', autoSaved: 'Taslak Otomatik Kaydedildi',
    inspector: 'Denetçi', attachments: 'Ekler', ai: 'YZ', stats: 'İstatistik', snapshots: 'Anlık Görüntü', lab: 'YZ Yazım Laboratuvarı',
    sparks: 'Yazım Kıvılcımları', rephrase: 'Yeniden Yaz', report: 'Profesyonel Stil Raporu', grammar: 'Dilbilgisi ve Yazım', plagiarism: 'İntihal Taraması',
    sticky: 'Yapışkan Cümleler', overused: 'Aşırı Kullanılanlar', cliches: 'Klişeler', pacing: 'Tempo Taraması', dialogue: 'Diyalog Kontrolü',
    vague: 'Belirsiz Dil', critique: 'Sanal Beta Okuyucu', analyze: 'Metni Analiz Et', settings: 'Kitap Ayarları', theme: 'Dizgi Teması',
    genre: 'Tür', tags: 'Etiketler', metadata: 'Meta Veri', generate: 'Üretim Dosyasını Oluştur', votes: 'Oy', reads: 'Okuma',
    world: 'Dünya Merkezi', visualizer: 'Görselleştirici', uiTheme: 'Arayüz Teması',
    boards: 'Fikir Panoları', templates: 'Şablonlar', collaboration: 'İşbirliği', share: 'Paylaş',
    generateSpark: 'Kıvılcım Oluştur', targetLanguage: 'Hedef Dil', translateManuscript: 'Taslağı Çevir',
    efficiencyScore: 'Verimlilik Skoru', styleScore: 'Stil Skoru', toneSentiment: 'Tone ve Duygu', themes: 'Temalar',
    detectedSources: 'Tespit Edilen Kaynaklar', part: 'Bölüm', voteForPart: 'Bu bölümü oyla', library: 'Kütüphane',
    readerPreview: 'Okuyucu Önizlemesi', binderTitle: 'Taslak Klasörü', findInHierarchy: 'Hiyerarşide bul...',
    newScene: 'Yeni Sahne', newSubSection: 'Yeni Alt Bölüm', deleteEntry: 'Girdiyi Sil', tools: 'Araçlar',
    reports: 'Raporlar', critiqueTab: 'Eleştiri', translate: 'Çevir', summoningAI: 'YZ Zekası Çağrılıyor...',
    aiIdle: 'YZ Yazım Laboratuvarı Boşta', aiIdleDesc: 'Taslağınızı geliştirmek için bir araç seçin veya bir kıvılcım istemi girin.',
    sectionStrategyNode: 'Bölüm Strateji Düğümü', activeDraft: 'Aktif Taslak', sectionWordCount: 'Bölüm Kelime Sayısı',
    minReadingTime: 'Min. Okuma Süresi', narrativeObjective: 'Anlatı Hedefi', intensityArc: 'Yoğunluk Eğrisi',
    sectionHealth: 'Bölüm Sağlığı', sequenceMap: 'Sıralama Haritası', newNarrativeScene: 'Yeni Anlatı Sahnesi',
    filterScenes: 'Sahneleri Filtrele', viewOptions: 'Görünüm Seçenekleri', sceneTitle: 'Sahne Başlığı', status: 'Durum',
    conflict: 'Çatışma', outcome: 'Sonuç', tension: 'Gerilim', importance: 'Önem', humor: 'Mizah',
    quality: 'Kalite', timeDay: 'Zaman / Gün', projectCastAssets: 'Karakterler ve Varlıklar', addCharacter: 'Karakter Ekle',
    addSetting: 'Mekan Ekle', addPlotObject: 'Nesne Ekle', totalManuscriptProgress: 'Toplam Taslak İlerlemesi',
    deadlineInsight: 'Teslim Tarihi Öngörüsü', daysLeft: 'Kalan Gün', wordsPerDay: 'Kelime / Gün', writingVelocity: 'Yazım Hızı',
    socialMetrics: 'Sosyal Metrikler', researchIntelligence: 'Araştırma Zekası', initializeFramework: 'Çerçeveyi Başlat',
    customArchitecture: 'Özel Mimari', workLog: 'Çalışma Günlüğü', newSession: 'Yeni Oturum', avgVelocity: 'Ort. Hız',
    follows: 'Takipçi', parts: 'Bölümler', lore: 'İlim', maps: 'Haritalar', bio: 'Biyografi', arc: 'Gelişim', goal: 'Hedef',
    narrative: 'Anlatı', plotThread: 'Kurgu Hattı', sessionHistory: 'Oturum Geçmişi', writingTime: 'Yazma Süresi',
    lifeTimeWords: 'Toplam Kelime', includes: 'İçerir', blueprintTitle: 'Anlatı Taslakları', blueprintDesc: 'Hikaye anlatımı zekanızı yapılandırmak için standartlaştırılmış çerçeveler.',
    standardNovel: 'Standart Roman', heroJourney: 'Kahramanın Yolculuğu', saveTheCat: 'Kediyi Kurtar', thrillerPulse: 'Gerilim Nabzı', academicMaster: 'Akademik Uzman', lifeLegacy: 'Yaşam Mirası',
    appLanguage: 'Uygulama Dili', projectLanguage: 'Çalışma Dili', startNewWork: 'Yeni Çalışma Başlat', projectTitle: 'Çalışma Başlığı', pickLanguage: 'Dil Seçin',
    manuscriptBlueprint: 'Taslak Tasarımı', welcomeBack: 'Hoş Geldiniz, Yazar', setupMessage: 'Lütfen çalışma alanı dil tercihlerinizi yapılandırın.',
    writing: 'Yazılıyor', exit: 'Çıkış'
  },
  Azerbaijani: {
    write: 'Yaz', split: 'Böl', board: 'Lövhə', plot: 'Süjet', outline: 'Plan', log: 'Gündəlik', cast: 'Heyət', reader: 'Oxu Rejimi',
    compile: 'Tərtib', typewriter: 'Makina', words: 'Söz', progress: 'Tərəqqi', autoSaved: 'Avtomatik Saxlanıldı',
    inspector: 'Müfəttiş', attachments: 'Əlavələr', ai: 'Sİ', stats: 'Statistika', snapshots: 'Anlıq Şəkillər', lab: 'Sİ Yazı Laboratoriyası',
    sparks: 'Yazi Qığılcımları', rephrase: 'Yenidən İfadə Et', report: 'Stil Hesabatı', grammar: 'Qrammatika və Orfoqrafiya', plagiarism: 'Plagiat Yoxlaması',
    sticky: 'Ağır Cümlələr', overused: 'Çox İşlənən Sözlər', cliches: 'Klielər', pacing: 'Tempo', dialogue: 'Dialoq Yoxlaması',
    vague: 'Qeyri-müəyyənlik', critique: 'Virtual Beta Oxucu', analyze: 'Əlyazmanı Analiz Et', settings: 'Kitab Ayarları', theme: 'Dizayn Mövzusu',
    genre: 'Janr', tags: 'Teqlər', metadata: 'Meta-məlumat', generate: 'Faylı Hazırla', votes: 'Səs', reads: 'Baxış',
    world: 'Dünya Mərkəzi', visualizer: 'Vizuallaşdırıcı', uiTheme: 'Arayüz Mövzusu',
    boards: 'İdeya Lövhələri', templates: 'Şablonlar', collaboration: 'Əməkdaşlıq', share: 'Paylaş',
    generateSpark: 'Qığılcım Yarat', targetLanguage: 'Hədəf Dil', translateManuscript: 'Mətni Tərcümə Et',
    efficiencyScore: 'Effektivlik Balı', styleScore: 'Stil Balı', toneSentiment: 'Ton və Hiss', themes: 'Mövzular',
    detectedSources: 'Tapılan Mənbələr', part: 'Hissə', voteForPart: 'Bu hissəyə səs ver', library: 'Kitabxana',
    readerPreview: 'Oxucu Baxışı', binderTitle: 'Əlyazma Qovluğu', findInHierarchy: 'Hiyerarşiyada tap...',
    newScene: 'Yeni Səhnə', newSubSection: 'Yeni Alt Bölmə', deleteEntry: 'Girişi Sil', tools: 'Alətlər',
    reports: 'Hesabatlar', critiqueTab: 'Tənqid', translate: 'Tərcümə Et', summoningAI: 'Sİ Çağırılır...',
    aiIdle: 'Sİ Yazı Laboratoriyası Gözləmədə', aiIdleDesc: 'Əlyazmanızı təkmilləşdirmək üçün bir alət seçin və ya bir qığılcım daxil edin.',
    sectionStrategyNode: 'Hissə Strategiya Düyməsi', activeDraft: 'Aktiv Qaralama', sectionWordCount: 'Hissə Söz Sayı',
    minReadingTime: 'Min. Oxu Müddəti', narrativeObjective: 'Hekayə Məqsədi', intensityArc: 'Gərginlik Qövsü',
    sectionHealth: 'Hissə Vəziyyəti', sequenceMap: 'Sıra Xəritəsi', newNarrativeScene: 'Yeni Süjet Səhnəsi',
    filterScenes: 'Səhnələri Filtrlə', viewOptions: 'Görünüş Seçimləri', sceneTitle: 'Səhnə Başlığı', status: 'Status',
    conflict: 'Münaqişə', outcome: 'Nəticə', tension: 'Gərginlik', importance: 'Vaciblik', humor: 'Yumor',
    quality: 'Keyfiyyət', timeDay: 'Vaxt / Gün', projectCastAssets: 'Heyət və Aktivlər', addCharacter: 'Personaj Əlavə Et',
    addSetting: 'Məkan Əlavə Et', addPlotObject: 'Obyekt Əlavə Et', totalManuscriptProgress: 'Ümumi Əlyazma Tərəqqisi',
    deadlineInsight: 'Son Tarix Proqnozu', daysLeft: 'Qalan Gün', wordsPerDay: 'Söz / Gün', writingVelocity: 'Yazı Sürəti',
    socialMetrics: 'Sosial Metriklər', researchIntelligence: 'Tədqiqat Zəkası', initializeFramework: 'Strukturu Başlat',
    customArchitecture: 'Xüsusi Memarlıq', workLog: 'İş Jurnalı', newSession: 'Yeni Sessiya', avgVelocity: 'Ort. Sürət',
    follows: 'İzləyici', parts: 'Hissələr', lore: 'Biliklər', maps: 'Xəritələr', bio: 'Bioqrafiya', arc: 'İnkişaf', goal: 'Məqsəd',
    narrative: 'Hekayə', plotThread: 'Süjet Xətti', sessionHistory: 'Sessiya Tarixçəsi', writingTime: 'Yazı Müddəti',
    lifeTimeWords: 'Cəmi Sözlər', includes: 'Daxildir', blueprintTitle: 'Hekayə Planları', blueprintDesc: 'Hekayə zəkanızı strukturlaşdırmaq üçün standartlaştırılmış çərçivələr.',
    standardNovel: 'Standart Roman', heroJourney: 'Qəhrəmanın Səyahəti', saveTheCat: 'Pişiyi Xilas Et', thrillerPulse: 'Triller Nəbzi', academicMaster: 'Akademik Ustad', lifeLegacy: 'Həyat Mirası',
    appLanguage: 'Tətbiq Dili', projectLanguage: 'İş Dili', startNewWork: 'Yeni İşə Başla', projectTitle: 'İş Başlığı', pickLanguage: 'Dil Seçin',
    manuscriptBlueprint: 'Əlyazma Planı', welcomeBack: 'Xoş Gəldiniz, Yazıçı', setupMessage: 'Lütfən iş sahənizin dil seçimlərini tənzimləyin.',
    writing: 'Yazılır', exit: 'Çıxış'
  },
  French: {
    write: 'Écrire', split: 'Scinder', board: 'Tableau', plot: 'Intrigue', outline: 'Plan', log: 'Journal', cast: 'Distribution', reader: 'Mode Lecture',
    compile: 'Compiler', typewriter: 'Machine à écrire', words: 'Mots', progress: 'Progrès', autoSaved: 'Enregistré automatiquement',
    inspector: 'Inspecteur', attachments: 'Pièces jointes', ai: 'IA', stats: 'Stats', snapshots: 'Captures', lab: 'Labo d’écriture IA',
    sparks: 'Étincelles d’écriture', rephrase: 'Reformuler', report: 'Rapport de style', grammar: 'Grammaire & Orthographe', plagiarism: 'Plagiat',
    sticky: 'Phrases collantes', overused: 'Mots surutilisés', cliches: 'Clichés', pacing: 'Rythme', dialogue: 'Dialogue',
    vague: 'Langage vague', critique: 'Bêta-lecteur virtuel', analyze: 'Analyser le manuscrit', settings: 'Paramètres', theme: 'Thème de mise en page',
    genre: 'Genre', tags: 'Étiquettes', metadata: 'Métadonnées', generate: 'Générer le fichier', votes: 'Votes', reads: 'Lectures',
    world: 'Moyeu du Monde', visualizer: 'Visualiseur', uiTheme: 'Thème d’Interface',
    boards: 'Tableaux d\'idées', templates: 'Modèles', collaboration: 'Collaboration', share: 'Partager',
    generateSpark: 'Générer une Étincelle', targetLanguage: 'Langue Cible', translateManuscript: 'Traduire le Manuscrit',
    efficiencyScore: 'Score d\'Efficacité', styleScore: 'Score de Style', toneSentiment: 'Ton & Sentiment', themes: 'Thèmes',
    detectedSources: 'Sources Détectées', part: 'Partie', voteForPart: 'Voter pour cette partie', library: 'Bibliothèque',
    readerPreview: 'Aperçu Lecteur', binderTitle: 'Classeur de Manuscrit', findInHierarchy: 'Chercher dans la hiérarchie...',
    newScene: 'Nouvelle Scène', newSubSection: 'Nouvelle Sous-section', deleteEntry: 'Supprimer l\'entrée', tools: 'Outils',
    reports: 'Rapports', critiqueTab: 'Critique', translate: 'Traduire', summoningAI: 'Appel de l\'IA...',
    aiIdle: 'Labo d\'IA en Veille', aiIdleDesc: 'Sélectionnez un outil ou entrez une invite pour enrichir votre texte.',
    sectionStrategyNode: 'Nœud Stratégique de Section', activeDraft: 'Brouillon Actif', sectionWordCount: 'Nombre de Mots',
    minReadingTime: 'Temps de Lecture Min.', narrativeObjective: 'Objectif Narratif', intensityArc: 'Arc d\'Intensité',
    sectionHealth: 'Santé de Section', sequenceMap: 'Carte Séquentielle', newNarrativeScene: 'Nouvelle Scène Narratif',
    filterScenes: 'Filtrer les Scènes', viewOptions: 'Options de Vue', sceneTitle: 'Titre de Scène', status: 'Statut',
    conflict: 'Conflit', outcome: 'Résultat', tension: 'Tension', importance: 'Importance', humor: 'Humour',
    quality: 'Qualité', timeDay: 'Temps / Jour', projectCastAssets: 'Distribution & Atouts', addCharacter: 'Ajouter Personnage',
    addSetting: 'Ajouter Cadre', addPlotObject: 'Ajouter Objet', totalManuscriptProgress: 'Progrès Total du Manuscrit',
    deadlineInsight: 'Aperçu de l\'Échéance', daysLeft: 'Jours Restants', wordsPerDay: 'Mots / Jour', writingVelocity: 'Vélocité d\'Écriture',
    socialMetrics: 'Métriques Sociales', researchIntelligence: 'Intelligence de Recherche', initializeFramework: 'Initialiser le Cadre',
    customArchitecture: 'Architecture Personnalisée', workLog: 'Journal de Travail', newSession: 'Nouvelle Session', avgVelocity: 'Vélocité Moy.',
    follows: 'Abonnés', parts: 'Parties', lore: 'Savoir', maps: 'Cartes', bio: 'Bio', arc: 'Arc', goal: 'But',
    narrative: 'Récit', plotThread: 'Fil de l\'Intrigue', sessionHistory: 'Historique des Sessions', writingTime: 'Temps d\'Écriture',
    lifeTimeWords: 'Total de Mots', includes: 'Comprend', blueprintTitle: 'Modèles Narratifs', blueprintDesc: 'Structures standardisées pour organiser votre intelligence narrative.',
    standardNovel: 'Roman Standard', heroJourney: 'Voyage du Héros', saveTheCat: 'Sauve le Chat', thrillerPulse: 'Pouls Thriller', academicMaster: 'Maître Académique', lifeLegacy: 'Héritage de Vie',
    appLanguage: 'Langue de l\'App', projectLanguage: 'Langue du Projet', startNewWork: 'Nouveau Projet', projectTitle: 'Titre du Projet', pickLanguage: 'Choisir la Langue',
    manuscriptBlueprint: 'Plan de Manuscrit', welcomeBack: 'Bienvenue, Auteur', setupMessage: 'Configurons vos préférences linguistiques.',
    writing: 'Écriture', exit: 'Quitter'
  },
  Spanish: {
    write: 'Escribir', split: 'Dividir', board: 'Tablero', plot: 'Trama', outline: 'Esquema', log: 'Registro', cast: 'Elenco', reader: 'Modo Lector',
    compile: 'Compilar', typewriter: 'Máquina de escribir', words: 'Palabras', progress: 'Progreso', autoSaved: 'Guardado automático',
    inspector: 'Inspector', attachments: 'Adjuntos', ai: 'IA', stats: 'Estadísticas', snapshots: 'Instantáneas', lab: 'Laboratorio de IA',
    sparks: 'Chispas de escritura', rephrase: 'Parafrasear', report: 'Informe de estilo', grammar: 'Gramática y Ortografía', plagiarism: 'Plagio',
    sticky: 'Frases pegajosas', overused: 'Palabras repetitivas', cliches: 'Clichés', pacing: 'Ritmo', dialogue: 'Diálogo',
    vague: 'Lenguaje vago', critique: 'Lector beta virtual', analyze: 'Analizar manuscrito', settings: 'Ajustes', theme: 'Tema de diseño',
    genre: 'Género', tags: 'Etiquetas', metadata: 'Metadatos', generate: 'Generar archivo', votes: 'Votos', reads: 'Lecturas',
    world: 'Centro Mundial', visualizer: 'Visualizador', uiTheme: 'Tema de Interfaz',
    boards: 'Tableros de ideas', templates: 'Plantillas', collaboration: 'Colaboración', share: 'Compartir',
    generateSpark: 'Generar Chispa', targetLanguage: 'Idioma Destino', translateManuscript: 'Traducir Manuscrito',
    efficiencyScore: 'Puntuación de Eficiencia', styleScore: 'Puntuación de Estilo', toneSentiment: 'Tono y Sentimiento', themes: 'Temas',
    detectedSources: 'Fuentes Detectadas', part: 'Parte', voteForPart: 'Votar por esta parte', library: 'Biblioteca',
    readerPreview: 'Vista Previa del Lector', binderTitle: 'Carpeta del Manuscrito', findInHierarchy: 'Buscar en jerarquía...',
    newScene: 'Nueva Escena', newSubSection: 'Nueva Subsección', deleteEntry: 'Eliminar Entrada', tools: 'Herramientas',
    reports: 'Informes', critiqueTab: 'Crítica', translate: 'Traducir', summoningAI: 'Invocando Inteligencia Artificial...',
    aiIdle: 'Laboratorio IA Inactivo', aiIdleDesc: 'Selecciona una herramienta o ingresa una chispa para mejorar tu obra.',
    sectionStrategyNode: 'Nodo Estratégico de Sección', activeDraft: 'Borrador Activo', sectionWordCount: 'Palabras de Sección',
    minReadingTime: 'Tiempo de Lectura Mín.', narrativeObjective: 'Objetivo Narrativo', intensityArc: 'Arco de Intensidad',
    sectionHealth: 'Salud de la Sección', sequenceMap: 'Mapa de Secuencia', newNarrativeScene: 'Nueva Escena Narrativa',
    filterScenes: 'Filtrar Escenas', viewOptions: 'Opciones de Vista', sceneTitle: 'Título de Escena', status: 'Estado',
    conflict: 'Conflicto', outcome: 'Resultado', tension: 'Tensión', importance: 'Importancia', humor: 'Humor',
    quality: 'Calidad', timeDay: 'Tiempo / Día', projectCastAssets: 'Elenco y Activos', addCharacter: 'Añadir Personaje',
    addSetting: 'Añadir Escenario', addPlotObject: 'Añadir Objeto', totalManuscriptProgress: 'Progreso Total del Manuscrito',
    deadlineInsight: 'Información de Plazo', daysLeft: 'Días Restantes', wordsPerDay: 'Palabras / Día', writingVelocity: 'Velocidad de Escritura',
    socialMetrics: 'Métricas Sociales', researchIntelligence: 'Inteligencia de Investigación', initializeFramework: 'Inicializar Marco',
    customArchitecture: 'Arquitectura Personalizada', workLog: 'Diario de Trabajo', newSession: 'Nueva Sesión', avgVelocity: 'Velocidad Prom.',
    follows: 'Seguidores', parts: 'Partes', lore: 'Conocimiento', maps: 'Mapas', bio: 'Bio', arc: 'Arco', goal: 'Meta',
    narrative: 'Narrativa', plotThread: 'Hilo de Trama', sessionHistory: 'Historial de Sesiones', writingTime: 'Tiempo de Escritura',
    lifeTimeWords: 'Total de Palabras', includes: 'Incluye', blueprintTitle: 'Planos Narrativos', blueprintDesc: 'Marcos estandarizados para estructurar su inteligencia narrativa.',
    standardNovel: 'Novela Estándar', heroJourney: 'El Viaje del Héroe', saveTheCat: 'Salva al Gato', thrillerPulse: 'Pulso Thriller', academicMaster: 'Maestro Académico', lifeLegacy: 'Legado de Vida',
    appLanguage: 'Idioma de la App', projectLanguage: 'Idioma del Proyecto', startNewWork: 'Iniciar Nuevo Trabajo', projectTitle: 'Título del Proyecto', pickLanguage: 'Elegir Idioma',
    manuscriptBlueprint: 'Plano del Manuscrito', welcomeBack: 'Bienvenido, Autor', setupMessage: 'Configura tus preferencias de idioma.',
    writing: 'Escribiendo', exit: 'Salir'
  },
  Italian: {
    write: 'Scrivere', split: 'Dividi', board: 'Bacheca', plot: 'Trama', outline: 'Schema', log: 'Diario', cast: 'Cast', reader: 'Lettura',
    compile: 'Compila', typewriter: 'Macchina da scrivere', words: 'Parole', progress: 'Progresso', autoSaved: 'Salvataggio automatico',
    inspector: 'Ispettore', attachments: 'Allegati', ai: 'IA', stats: 'Statistiche', snapshots: 'Istantanee', lab: 'Laboratorio IA',
    sparks: 'Scintille', rephrase: 'Riformula', report: 'Rapporto stile', grammar: 'Grammatica e Ortografia', plagiarism: 'Plagio',
    sticky: 'Frases appiccicose', overused: 'Parole abusate', cliches: 'Cliché', pacing: 'Ritmo', dialogue: 'Dialogo',
    vague: 'Linguaggio vago', critique: 'Lettore beta virtuale', analyze: 'Analizza manoscritto', settings: 'Impostazioni', theme: 'Tema editoriale',
    genre: 'Genere', tags: 'Tag', metadata: 'Metadati', generate: 'Genera file', votes: 'Voti', reads: 'Letture',
    world: 'Hub del Mondo', visualizer: 'Visualizzatore', uiTheme: 'Tema dell’Interfaccia',
    boards: 'Bacheche idee', templates: 'Modelli', collaboration: 'Collaborazione', share: 'Condividi',
    generateSpark: 'Genera Scintilla', targetLanguage: 'Lingua di Destinazione', translateManuscript: 'Traduci Manuscrit',
    efficiencyScore: 'Punteggio Efficienza', styleScore: 'Punteggio Stile', toneSentiment: 'Tono e Sentimento', themes: 'Temi',
    detectedSources: 'Fonti Rilevate', part: 'Parte', voteForPart: 'Vota questa parte', library: 'Libreria',
    readerPreview: 'Anteprima Lettore', binderTitle: 'Raccoglitore Manoscritto', findInHierarchy: 'Cerca nella gerarchia...',
    newScene: 'Nuova Scena', newSubSection: 'Nuova Sotto-sezione', deleteEntry: 'Elimina Voce', tools: 'Strumenti',
    reports: 'Rapporti', critiqueTab: 'Critica', translate: 'Traduci', summoningAI: 'Invocazione IA...',
    aiIdle: 'Laboratorio IA Inattivo', aiIdleDesc: 'Seleziona uno strumento o inserisci una scintilla per migliorare il tuo testo.',
    sectionStrategyNode: 'Nodo Strategico di Sezione', activeDraft: 'Bozza Attiva', sectionWordCount: 'Parole Sezione',
    minReadingTime: 'Tempo di Lettura Min.', narrativeObjective: 'Obiettivo Narrativo', intensityArc: 'Arco di Intensità',
    sectionHealth: 'Salute della Sezione', sequenceMap: 'Mappa Sequenziale', newNarrativeScene: 'Nuova Scena Narrativa',
    filterScenes: 'Filtra Scene', viewOptions: 'Opzioni di Vista', sceneTitle: 'Titolo Scena', status: 'Stato',
    conflict: 'Conflitto', outcome: 'Risultato', tension: 'Tensione', importance: 'Importanza', humor: 'Umorismo',
    quality: 'Qualità', timeDay: 'Tempo / Giorno', projectCastAssets: 'Cast & Risorse', addCharacter: 'Aggiungi Personaggio',
    addSetting: 'Aggiungi Ambientazione', addPlotObject: 'Aggiungi Oggetto', totalManuscriptProgress: 'Progresso Totale Manoscritto',
    deadlineInsight: 'Analisi Scadenza', daysLeft: 'Giorni Rimasti', wordsPerDay: 'Parole / Giorno', writingVelocity: 'Velocità di Scrittura',
    socialMetrics: 'Metriche Sociali', researchIntelligence: 'Intelligenza di Ricerca', initializeFramework: 'Inizializza Framework',
    customArchitecture: 'Architettura Personalizzata', workLog: 'Diario di Lavoro', newSession: 'Nuova Sessione', avgVelocity: 'Velocità Media',
    follows: 'Seguaci', parts: 'Parti', lore: 'Lore', maps: 'Mappe', bio: 'Biografia', arc: 'Arco', goal: 'Obiettivo',
    narrative: 'Narrativa', plotThread: 'Filo della Trama', sessionHistory: 'Cronologia Sessioni', writingTime: 'Tempo di Scrittura',
    lifeTimeWords: 'Parole Totali', includes: 'Include', blueprintTitle: 'Blueprint Narrativi', blueprintDesc: 'Strutture standardizzate per organizzare la tua intelligenza narrativa.',
    standardNovel: 'Romanzo Standard', heroJourney: 'Il Viaggio dell\'Eroe', saveTheCat: 'Salva il Gatto', thrillerPulse: 'Battito Thriller', academicMaster: 'Maestro Accademico', lifeLegacy: 'Eredità di Vita',
    appLanguage: 'Lingua dell\'App', projectLanguage: 'Lingua del Lavoro', startNewWork: 'Inizia Nuovo Lavoro', projectTitle: 'Titolo del Lavoro', pickLanguage: 'Scegli Lingua',
    manuscriptBlueprint: 'Schema del Manoscritto', welcomeBack: 'Benvenuto, Autore', setupMessage: 'Configura le preferenze per il workspace.',
    writing: 'Scrittura', exit: 'Esci'
  },
  Portuguese: {
    write: 'Escrever', split: 'Dividir', board: 'Mural', plot: 'Enredo', outline: 'Esboço', log: 'Diário', cast: 'Elenco', reader: 'Modo Lector',
    compile: 'Compilar', typewriter: 'Máquina de escrever', words: 'Palavras', progress: 'Progresso', autoSaved: 'Salvo automaticamente',
    inspector: 'Inspetor', attachments: 'Anexos', ai: 'IA', stats: 'Estatísticas', snapshots: 'Capturas', lab: 'Laboratório IA',
    sparks: 'Faíscas', rephrase: 'Reescrever', report: 'Relatório de estilo', grammar: 'Gramática e Ortografia', plagiarism: 'Plágio',
    sticky: 'Frases coladas', overused: 'Palavras repetitivas', cliches: 'Clichés', pacing: 'Ritmo', dialogue: 'Dialogo',
    vague: 'Linguagem vaga', critique: 'Leitor beta virtual', analyze: 'Analisar manuscrito', settings: 'Configurações', theme: 'Tema editorial',
    genre: 'Gênero', tags: 'Etiquetas', metadata: 'Metadatos', generate: 'Gerar arquivo', votes: 'Votos', reads: 'Lecturas',
    world: 'Núcleo Mundial', visualizer: 'Visualizador', uiTheme: 'Tema da Interface',
    boards: 'Murais de ideas', templates: 'Modelos', collaboration: 'Colaboração', share: 'Compartilhar',
    generateSpark: 'Gerar Faísca', targetLanguage: 'Idioma Destino', translateManuscript: 'Traduzir Manuscrito',
    efficiencyScore: 'Pontuação de Eficiência', styleScore: 'Pontuação de Estilo', toneSentiment: 'Tom e Sentimento', themes: 'Temas',
    detectedSources: 'Fontes Detetadas', part: 'Parte', voteForPart: 'Votar nesta parte', library: 'Biblioteca',
    readerPreview: 'Pré-visualização do Leitor', binderTitle: 'Fichário do Manuscrito', findInHierarchy: 'Procurar na hierarquia...',
    newScene: 'Nova Cena', newSubSection: 'Nova Sub-secção', deleteEntry: 'Eliminar Entrada', tools: 'Ferramentas',
    reports: 'Relatórios', critiqueTab: 'Crítica', translate: 'Traduzir', summoningAI: 'Convocando IA...',
    aiIdle: 'Laboratorio IA Inativo', aiIdleDesc: 'Escolha uma ferramenta ou introduza uma faísca para aperfeiçoar o seu texto.',
    sectionStrategyNode: 'Nó de Estratégia de Secção', activeDraft: 'Rascunho Ativo', sectionWordCount: 'Palavras da Secção',
    minReadingTime: 'Tempo de Letura Mín.', narrativeObjective: 'Objetivo Narrativo', intensityArc: 'Arco de Intensidade',
    sectionHealth: 'Saúde da Secção', sequenceMap: 'Mapa de Sequência', newNarrativeScene: 'Nova Cena Narrativa',
    filterScenes: 'Filtrar Cenas', viewOptions: 'Opções de Visualização', sceneTitle: 'Título da Cena', status: 'Estado',
    conflict: 'Conflito', outcome: 'Resultado', tension: 'Tensão', importance: 'Importância', humor: 'Humor',
    quality: 'Qualidade', timeDay: 'Tempo / Dia', projectCastAssets: 'Elenco & Ativos', addCharacter: 'Adicionar Personagem',
    addSetting: 'Adicionar Cenário', addPlotObject: 'Adicionar Objeto', totalManuscriptProgress: 'Progresso Total do Manuscrito',
    deadlineInsight: 'Insight de Prazo', daysLeft: 'Dias Restantes', wordsPerDay: 'Palavras / Dia', writingVelocity: 'Velocidade de Escrita',
    socialMetrics: 'Métricas Sociais', researchIntelligence: 'Inteligência de Pesquisa', initializeFramework: 'Inicializar Estrutura',
    customArchitecture: 'Arquitectura Personalizada', workLog: 'Diário de Trabalho', newSession: 'Nova Sessão', avgVelocity: 'Velocidade Méd.',
    follows: 'Seguidores', parts: 'Partes', lore: 'Lore', maps: 'Maps', bio: 'Bio', arc: 'Arco', goal: 'Objetivo',
    narrative: 'Narrativa', plotThread: 'Linha de Trama', sessionHistory: 'Histórico de Sessões', writingTime: 'Tempo de Escrita',
    lifeTimeWords: 'Total de Palavras', includes: 'Inclui', blueprintTitle: 'Blueprints Narrativos', blueprintDesc: 'Estruturas padronizadas para organizar a sua inteligência narrativa.',
    standardNovel: 'Romance Padrão', heroJourney: 'A Jornada do Herói', saveTheCat: 'Salve o Gato', thrillerPulse: 'Pulso Thriller', academicMaster: 'Mestre Académico', lifeLegacy: 'Legado de Vida',
    appLanguage: 'Idioma da App', projectLanguage: 'Idioma do Trabalho', startNewWork: 'Iniciar Novo Trabalho', projectTitle: 'Título do Trabalho', pickLanguage: 'Escolher Idioma',
    manuscriptBlueprint: 'Plano do Manuscrito', welcomeBack: 'Bem-vindo, Autor', setupMessage: 'Configure suas preferências linguísticas do workspace.',
    writing: 'Escrita', exit: 'Sair'
  }
};

export const BOOK_THEMES = [
  { id: 'Classic', description: 'Serif, balanced margins, standard chapter headers.', font: 'Merriweather' },
  { id: 'Romance', description: 'Elegant flourishes, wider line spacing, soft italics.', font: 'Georgia' },
  { id: 'Thriller', description: 'Tight tracking, bold sans-serif headers, high contrast.', font: 'Inter' },
  { id: 'Modern', description: 'Clean layout, asymmetrical headers, minimalist style.', font: 'Inter' },
  { id: 'Academic', description: 'Numbered sections, standard 12pt type, footnote support.', font: 'Times New Roman' },
];

export const INITIAL_PROJECT: any = {
  id: 'proj-1',
  name: 'NowElla',
  language: 'English',
  uiLanguage: 'English',
  genre: 'Science Fiction',
  tags: ['Space Opera', 'Artificial Intelligence', 'Cyberpunk'],
  coverUrl: 'https://picsum.photos/seed/scifi-cover/600/900',
  authorName: 'Elara Vance',
  socialMetrics: {
    totalVotes: 1240,
    totalReads: 45200,
    followers: 890
  },
  boards: [
    {
      id: 'board-1',
      name: 'Plot Brainstorming',
      columns: [
        { id: 'col-1', title: 'To Do', cards: [{ id: 'card-1', title: 'Introduce the Villain', content: 'Needs a dramatic entry at the orbital station.' }] },
        { id: 'col-2', title: 'In Progress', cards: [{ id: 'card-2', title: 'The Chronometer Mystery', content: 'Why does it stop at 04:00?' }] },
        { id: 'col-3', title: 'Done', cards: [{ id: 'card-3', title: 'Opening Scene', content: 'Elara waking up in the cockpit.' }] }
      ]
    }
  ],
  binder: [
    {
      id: 'front-matter',
      title: 'Front Matter',
      type: 'front-matter',
      content: '',
      children: [
        { id: 'fm-1', title: 'Title Page', type: 'document', content: '<h1 style="text-align:center">NowElla</h1><p style="text-align:center">by Elara Vance</p>' },
        { id: 'fm-2', title: 'Copyright', type: 'document', content: '<p>© 2024 Elara Vance. All rights reserved.</p>' },
        { id: 'fm-3', title: 'Dedication', type: 'document', content: '<p style="text-align:center; font-style:italic">For those who look up at the stars and wonder.</p>' }
      ]
    },
    {
      id: 'manuscript',
      title: 'Manuscript (Body)',
      type: 'folder',
      content: '',
      children: [
        {
          id: 'ch-1',
          title: 'Chapter 1: The Awakening',
          type: 'folder',
          content: '',
          children: [
            {
              id: 'sc-1',
              title: 'Scene 1: The Void',
              type: 'document',
              content: '<p>The stars were silent. Far too silent for Elara\'s liking. She checked the chronometer again—three hours until atmospheric entry, and the engines were still cooling.</p><p><i>"Maybe silence is what we need,"</i> she whispered to the empty cockpit.</p>',
              synopsis: 'Elara wakes up in deep space and realizes she is lost.',
              socialStats: { votes: 45, reads: 1200, commentsCount: 12 },
              yWriterData: {
                conflict: 'Atmospheric entry failure imminent.',
                outcome: 'Elara finds a signal but loses engine power.',
                tension: 8,
                importance: 10,
                timeOfDay: '04:00 AM',
                inStoryDay: 1,
                storylineId: 'sl-1'
              },
              metadata: { status: 'First Draft', lastEdited: Date.now(), linkedCharacters: ['char-1'] }
            }
          ]
        }
      ]
    },
    {
      id: 'back-matter',
      title: 'Back Matter',
      type: 'back-matter',
      content: '',
      children: [
        { id: 'bm-1', title: 'Acknowledgments', type: 'document', content: '<p>Thanks to the crew of the ISS.</p>' },
        { id: 'bm-2', title: 'About the Author', type: 'document', content: '<p>Elara Vance is a navigator from the Neo-Tokyo cluster.</p>' }
      ]
    },
    {
      id: 'characters-folder',
      title: 'Characters',
      type: 'folder',
      children: []
    }
  ],
  snapshots: [],
  storylines: [
    { id: 'sl-1', name: 'Main Plot', color: '#6366f1' },
    { id: 'sl-2', name: 'Past', color: '#ec4899' },
    { id: 'sl-3', name: 'Signal', color: '#f59e0b' }
  ],
  worldBuilding: {
    lore: [
      { id: 'lore-1', category: 'Technology', title: 'FTL Navigation', content: 'Faster Than Light travel requires precise calculations and the use of Chrono-Relays.' }
    ],
    maps: [
      { id: 'map-1', name: 'Nebula Sector 7', imageUrl: 'https://picsum.photos/seed/nebula/1200/800', pins: [] }
    ]
  },
  writingLog: [
    { id: 'log-1', timestamp: Date.now() - 86400000, wordsAdded: 1200, sessionMinutes: 45, note: 'Good progress on Chapter 1.' },
    { id: 'log-2', timestamp: Date.now() - 172800000, wordsAdded: 850, sessionMinutes: 30, note: 'Struggled with the ending of Scene 2.' }
  ],
  characters: [
    {
      id: 'char-1',
      name: 'Elara Vance',
      role: 'Protagonist',
      traits: ['Determined', 'Anxious'],
      goals: 'Find home.',
      description: 'A brave starship pilot with silver hair and keen blue eyes.',
      imageUrl: 'https://picsum.photos/seed/elara/400/400'
    }
  ],
  items: [
    { id: 'item-1', name: 'The Chronometer', description: 'A relic of the Old Republic.', isMacGuffin: true }
  ],
  locations: [
    { id: 'loc-1', name: 'Neo-Tokyo Hub', description: 'A bustling neon metropolis floating in the clouds.' }
  ],
  goals: {
    dailyWordGoal: 1000,
    totalWordGoal: 50000,
    deadline: '2024-12-31'
  },
  settings: {
    typewriterMode: false,
    markupMode: false,
    bookTheme: 'Classic',
    uiTheme: 'light',
    pageMargins: 40,
    lineSpacing: 1.5,
    pageOrientation: 'portrait'
  }
};
