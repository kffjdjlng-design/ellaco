
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { INITIAL_PROJECT, TRANSLATIONS, SUPPORTED_LANGUAGES } from './constants';
import { BinderItem, ViewMode, ProjectState, Snapshot, BookTheme, UITheme, Language } from './types';
import Sidebar from './components/Sidebar';
import Editor from './components/Editor';
import Corkboard from './components/Corkboard';
import Outliner from './components/Outliner';
import CharacterSheet from './components/CharacterSheet';
import Header from './components/Header';
import AISparks from './components/AISparks';
import StatsPanel from './components/StatsPanel';
import InspectorPanel from './components/InspectorPanel';
import AttachmentsPanel from './components/AttachmentsPanel';
import Storyboard from './components/Storyboard';
import WritingLog from './components/WritingLog';
import ReaderView from './components/ReaderView';
import WorldBuilding from './components/WorldBuilding';
import ResearchLab from './components/ResearchLab';
import BoardView from './components/BoardView';
import TemplatesPanel from './components/TemplatesPanel';
import SectionDesigner from './components/SectionDesigner';
import ProductionHub from './components/ProductionHub';
import Dashboard from './components/Dashboard';
import { FileText, X, Sparkles, BookOpen, Globe, Check } from 'lucide-react';

const App: React.FC = () => {
  const [project, setProject] = useState<ProjectState>(() => {
    const saved = localStorage.getItem('nowella_project_data');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return { ...INITIAL_PROJECT };
      }
    }
    return { ...INITIAL_PROJECT };
  });

  const [activeItemId, setActiveItemId] = useState<string>('sc-1');
  const [viewMode, setViewMode] = useState<ViewMode>('dashboard');
  const [isCompositionMode, setIsCompositionMode] = useState(false);
  const [showRightPanel, setShowRightPanel] = useState(true);
  const [rightPanelTab, setRightPanelTab] = useState<'inspector' | 'attachments' | 'ai' | 'stats' | 'snapshots'>('inspector');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [isFirstLaunch, setIsFirstLaunch] = useState(() => !localStorage.getItem('nowella_initialized'));

  // For the New Project Flow
  const [newProjDraft, setNewProjDraft] = useState({
    title: '',
    language: project.language as Language,
    genre: 'Fiction'
  });

  // Navigation History Logic
  const [navHistory, setNavHistory] = useState<{ viewMode: ViewMode; itemId: string }[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const isNavigatingHistory = useRef(false);

  useEffect(() => {
    localStorage.setItem('nowella_project_data', JSON.stringify(project));
  }, [project]);

  // Record history when viewMode or activeItemId changes
  useEffect(() => {
    if (isNavigatingHistory.current) {
      isNavigatingHistory.current = false;
      return;
    }

    const currentEntry = navHistory[historyIndex];
    if (currentEntry?.viewMode === viewMode && currentEntry?.itemId === activeItemId) {
      return;
    }

    const newEntry = { viewMode, itemId: activeItemId };
    const newHistory = navHistory.slice(0, historyIndex + 1);
    setNavHistory([...newHistory, newEntry]);
    setHistoryIndex(newHistory.length);
  }, [viewMode, activeItemId]);

  const handleGoBack = () => {
    if (historyIndex > 0) {
      isNavigatingHistory.current = true;
      const prevIndex = historyIndex - 1;
      const entry = navHistory[prevIndex];
      setHistoryIndex(prevIndex);
      setViewMode(entry.viewMode);
      setActiveItemId(entry.itemId);
    }
  };

  const handleGoForward = () => {
    if (historyIndex < navHistory.length - 1) {
      isNavigatingHistory.current = true;
      const nextIndex = historyIndex + 1;
      const entry = navHistory[nextIndex];
      setHistoryIndex(nextIndex);
      setViewMode(entry.viewMode);
      setActiveItemId(entry.itemId);
    }
  };

  const handleRefresh = () => {
    setViewMode('dashboard');
  };

  // Translation is explicitly tied to uiLanguage
  const t = useCallback((key: string) => {
    const uiLang = project.uiLanguage || project.language || 'English';
    return TRANSLATIONS[uiLang][key] || key;
  }, [project.uiLanguage, project.language]);

  const findItemById = (items: BinderItem[], id: string): BinderItem | undefined => {
    for (const item of items) {
      if (item.id === id) return item;
      if (item.children) {
        const found = findItemById(item.children, id);
        if (found) return found;
      }
    }
    return undefined;
  };

  const activeItem = useMemo(() => findItemById(project.binder, activeItemId), [project.binder, activeItemId]);

  const updateBinder = (newBinder: BinderItem[]) => {
    setProject(prev => ({ ...prev, binder: newBinder }));
  };

  const updateContent = (id: string, content: string) => {
    const updateInTree = (items: BinderItem[]): BinderItem[] => {
      return items.map(item => {
        if (item.id === id) {
          return { ...item, content, metadata: { ...item.metadata, lastEdited: Date.now() } };
        }
        if (item.children) {
          return { ...item, children: updateInTree(item.children) };
        }
        return item;
      });
    };
    updateBinder(updateInTree(project.binder));
  };

  const updateItemMetadata = (id: string, updates: Partial<BinderItem>) => {
    const updateInTree = (items: BinderItem[]): BinderItem[] => {
      return items.map(item => {
        if (item.id === id) return { ...item, ...updates };
        if (item.children) return { ...item, children: updateInTree(item.children) };
        return item;
      });
    };
    updateBinder(updateInTree(project.binder));
  };

  const addItemToBinder = (parentId: string | null, type: 'folder' | 'document') => {
    const newItem: BinderItem = {
      id: `item-${Date.now()}`,
      title: type === 'folder' ? t('newSubSection') : t('newScene'),
      type: type as any,
      content: '',
      children: type === 'folder' ? [] : undefined,
      metadata: { status: 'To Do', lastEdited: Date.now() }
    };

    if (!parentId) {
      updateBinder([...project.binder, newItem]);
    } else {
      const addToParent = (items: BinderItem[]): BinderItem[] => {
        return items.map(item => {
          if (item.id === parentId) {
            return { ...item, children: [...(item.children || []), newItem] };
          }
          if (item.children) return { ...item, children: addToParent(item.children) };
          return item;
        });
      };
      updateBinder(addToParent(project.binder));
    }
    setActiveItemId(newItem.id);
    setViewMode('editor');
  };

  const deleteItemFromBinder = (id: string) => {
    const removeFromTree = (items: BinderItem[]): BinderItem[] => {
      return items.filter(item => item.id !== id).map(item => ({
        ...item,
        children: item.children ? removeFromTree(item.children) : undefined
      }));
    };
    updateBinder(removeFromTree(project.binder));
  };

  const updateProject = (updates: Partial<ProjectState>) => {
    setProject(prev => ({ ...prev, ...updates }));
  };

  const handleSelectItem = (id: string) => {
    setActiveItemId(id);
    const item = findItemById(project.binder, id);
    if (item?.type === 'document') {
      setViewMode('editor');
    } else if (item?.type === 'folder' || item?.type === 'front-matter' || item?.type === 'back-matter') {
      setViewMode('editor'); // Folders use SectionDesigner inside Editor view
    }
  };

  const createNewProject = () => {
    const initialSceneId = `sc-new-${Date.now()}`;
    const newProj: ProjectState = {
      ...INITIAL_PROJECT,
      id: `proj-${Date.now()}`,
      name: newProjDraft.title || 'Untitled Work',
      language: newProjDraft.language,
      uiLanguage: project.uiLanguage, 
      genre: newProjDraft.genre,
      writingLog: [],
      binder: [
        {
          id: 'manuscript-root',
          title: t('manuscriptBlueprint'),
          type: 'folder',
          content: '',
          children: [
            {
              id: initialSceneId,
              title: t('newNarrativeScene'),
              type: 'document',
              content: '<p></p>',
              metadata: { status: 'To Do', lastEdited: Date.now() }
            }
          ]
        }
      ]
    };
    setProject(newProj);
    setActiveItemId(initialSceneId);
    setViewMode('dashboard');
    setIsNewProjectModalOpen(false);
  };

  const handleInitializeUI = (lang: Language) => {
    setProject(prev => ({ ...prev, uiLanguage: lang }));
    localStorage.setItem('nowella_initialized', 'true');
    setIsFirstLaunch(false);
  };

  return (
    <div className={`flex flex-col h-screen select-none theme-${project.settings.uiTheme} transition-colors duration-300`}>
      {!isCompositionMode && viewMode !== 'reader' && (
        <Header 
          projectName={project.name} 
          projectLanguage={project.language}
          uiLanguage={project.uiLanguage || 'English'}
          setProjectLanguage={(l) => updateProject({ language: l })}
          setUILanguage={(l) => updateProject({ uiLanguage: l })}
          viewMode={viewMode} 
          setViewMode={setViewMode}
          isCompositionMode={isCompositionMode}
          setIsCompositionMode={setIsCompositionMode}
          showRightPanel={showRightPanel}
          setShowRightPanel={setShowRightPanel}
          typewriterMode={project.settings.typewriterMode}
          toggleTypewriter={() => updateProject({ settings: { ...project.settings, typewriterMode: !project.settings.typewriterMode } })}
          t={t}
          canGoBack={historyIndex > 0}
          canGoForward={historyIndex < navHistory.length - 1}
          onGoBack={handleGoBack}
          onGoForward={handleGoForward}
          onRefresh={handleRefresh}
          onNewProject={() => {
            setNewProjDraft({ title: '', language: project.language, genre: 'Fiction' });
            setIsNewProjectModalOpen(true);
          }}
        />
      )}

      <div className="flex-1 overflow-hidden flex">
        {!isCompositionMode && viewMode !== 'reader' && (
          <Sidebar 
            binder={project.binder} 
            activeId={activeItemId} 
            onSelect={handleSelectItem}
            onAddItem={addItemToBinder}
            onDeleteItem={deleteItemFromBinder}
            onOpenResearch={() => setViewMode('research')}
            onOpenBoards={() => setViewMode('boards')}
            onOpenTemplates={() => setViewMode('templates')}
            t={t}
          />
        )}

        <main className={`flex-1 relative overflow-hidden flex transition-all ${isCompositionMode || viewMode === 'reader' ? 'p-0' : 'p-4 gap-4'}`}>
          {viewMode === 'reader' && <ReaderView project={project} onBack={() => setViewMode('editor')} t={t} />}
          {viewMode === 'dashboard' && <Dashboard project={project} onSelectScene={handleSelectItem} setViewMode={setViewMode} t={t} />}
          
          {viewMode === 'world' && (
            <WorldBuilding 
              project={project} 
              updateProject={updateProject} 
              t={t} 
              onBackToStudio={() => setViewMode('dashboard')} 
            />
          )}

          {viewMode === 'research' && <ResearchLab language={project.language} t={t} />}
          {viewMode === 'boards' && <BoardView boards={project.boards} updateProject={updateProject} t={t} />}
          {viewMode === 'templates' && <TemplatesPanel onSelect={() => setViewMode('editor')} t={t} onBack={() => setViewMode('dashboard')} />}
          {viewMode === 'compile' && <ProductionHub project={project} t={t} />}

          {(viewMode === 'editor' || viewMode === 'split') && (
            <div className={`flex w-full gap-4 h-full`}>
               <div className="flex-1 overflow-hidden transition-all">
                 {activeItem && (
                    ['folder', 'front-matter', 'back-matter'].includes(activeItem.type) ? (
                      <SectionDesigner 
                        folder={activeItem} 
                        onSelectScene={(id) => setActiveItemId(id)}
                        onAddScene={(pid) => addItemToBinder(pid, 'document')}
                        t={t}
                      />
                    ) : (
                      <Editor 
                        item={activeItem} 
                        onContentChange={(c) => updateContent(activeItemId, c)} 
                        onUpdateMetadata={(u) => updateItemMetadata(activeItemId, u)}
                        isCompositionMode={isCompositionMode}
                        setIsCompositionMode={setIsCompositionMode}
                        typewriterMode={project.settings.typewriterMode}
                        markupMode={project.settings.markupMode}
                        settings={project.settings}
                        onUpdateSettings={(s) => updateProject({ settings: { ...project.settings, ...s } })}
                        t={t}
                      />
                    )
                 )}
               </div>
            </div>
          )}

          {viewMode === 'corkboard' && activeItem && <Corkboard folder={activeItem} onSelectItem={handleSelectItem} t={t} />}
          {viewMode === 'outliner' && activeItem && <Outliner folder={activeItem} storylines={project.storylines} onUpdateItem={updateItemMetadata} t={t} />}
          {viewMode === 'characters' && <div className="w-full overflow-y-auto pr-2"><CharacterSheet characters={project.characters} locations={project.locations} items={project.items} t={t} /></div>}
          {viewMode === 'storyboard' && <Storyboard binder={project.binder} onSelect={handleSelectItem} t={t} />}
          {viewMode === 'log' && <WritingLog logs={project.writingLog} t={t} />}
        </main>

        {!isCompositionMode && viewMode !== 'reader' && showRightPanel && !['world', 'research', 'boards', 'compile', 'templates', 'dashboard'].includes(viewMode) && (
          <aside className="w-80 sidebar-bg border-l border-slate-200 flex flex-col shadow-sm transition-colors duration-300">
             <div className="flex border-b border-slate-200 overflow-x-auto no-scrollbar">
                {(['inspector', 'attachments', 'ai', 'stats', 'snapshots'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setRightPanelTab(tab)}
                    className={`px-4 py-3 text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition ${
                      rightPanelTab === tab ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    {t(tab)}
                  </button>
                ))}
             </div>
             <div className="flex-1 overflow-y-auto">
                {rightPanelTab === 'inspector' && activeItem && <InspectorPanel item={activeItem} characters={project.characters} storyItems={project.items} storylines={project.storylines} onUpdate={(updates) => updateItemMetadata(activeItem.id, updates)} t={t} />}
                {rightPanelTab === 'attachments' && activeItem && <AttachmentsPanel item={activeItem} onUpdate={(attachments) => updateItemMetadata(activeItem.id, { attachments })} t={t} />}
                {rightPanelTab === 'ai' && <AISparks context={activeItem?.content || ''} language={project.language} t={t} />}
                {rightPanelTab === 'stats' && <StatsPanel project={project} t={t} />}
             </div>
          </aside>
        )}
      </div>

      {!isCompositionMode && viewMode !== 'reader' && (
        <footer className="h-8 header-bg border-t border-slate-200 flex items-center px-4 text-[10px] text-slate-500 justify-between uppercase tracking-widest font-medium">
          <div className="flex gap-6">
            <span className="flex items-center gap-1 font-bold"><FileText size={10} /> {(activeItem?.content || '').replace(/<[^>]*>/g, '').split(/\s+/).filter(x => x.length > 0).length || 0} {t('words').toUpperCase()}</span>
          </div>
          <div className="flex items-center gap-2 text-indigo-500">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span>{t('autoSaved')}</span>
          </div>
        </footer>
      )}

      {/* Share Modal */}
      {isShareModalOpen && (
        <div className="fixed inset-0 z-[100] bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-[32px] w-full max-w-lg overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-8 space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black text-slate-800">{t('collaboration')}</h3>
                <button onClick={() => setIsShareModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition"><X size={20} /></button>
              </div>
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <p className="text-sm text-slate-500">{t('shareSubtitle')}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* New Project Blueprint Modal */}
      {isNewProjectModalOpen && (
        <div className="fixed inset-0 z-[120] bg-indigo-950/60 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="bg-white rounded-[40px] w-full max-w-2xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300 border border-white/20">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="bg-indigo-600 p-12 text-white flex flex-col justify-between relative overflow-hidden">
                <div className="absolute top-0 right-0 p-12 opacity-10"><Sparkles size={160} /></div>
                <div className="space-y-4 relative z-10">
                  <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                    <BookOpen size={24} />
                  </div>
                  <h2 className="text-3xl font-black leading-tight">{t('startNewWork')}</h2>
                  <p className="text-indigo-100 text-sm leading-relaxed">{t('blueprintDesc')}</p>
                </div>
                <div className="text-[10px] font-black uppercase tracking-[0.3em] opacity-40">NowElla Engine v2.5</div>
              </div>

              <div className="p-12 space-y-8">
                <div className="space-y-6">
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">{t('projectTitle')}</label>
                      <input 
                        autoFocus
                        value={newProjDraft.title}
                        onChange={(e) => setNewProjDraft({...newProjDraft, title: e.target.value})}
                        className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 text-sm font-bold text-slate-700 focus:outline-none focus:border-indigo-500 transition-all"
                        placeholder="e.g. Echoes of the Void"
                      />
                   </div>

                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">{t('pickLanguage')}</label>
                      <div className="grid grid-cols-2 gap-2">
                        {SUPPORTED_LANGUAGES.map(lang => (
                          <button
                            key={lang.name}
                            onClick={() => setNewProjDraft({...newProjDraft, language: lang.name})}
                            className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border text-[10px] font-black uppercase tracking-tight transition-all ${
                              newProjDraft.language === lang.name ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-100' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                            }`}
                          >
                            <Globe size={12} /> {lang.label}
                          </button>
                        ))}
                      </div>
                   </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button 
                    onClick={() => setIsNewProjectModalOpen(false)}
                    className="flex-1 py-4 text-xs font-black uppercase tracking-widest text-slate-400 hover:text-slate-600 transition"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={createNewProject}
                    disabled={!newProjDraft.title}
                    className="flex-[2] py-4 bg-slate-900 text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-slate-200 hover:scale-[1.02] active:scale-95 transition disabled:opacity-50"
                  >
                    {t('initializeFramework')}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* First Launch / Initial setup modal */}
      {isFirstLaunch && (
        <div className="fixed inset-0 z-[200] bg-slate-900 flex items-center justify-center p-6 overflow-hidden">
          <div className="absolute inset-0 opacity-20">
             <div className="absolute top-0 -left-1/4 w-1/2 h-full bg-indigo-500 blur-[160px] rounded-full"></div>
             <div className="absolute bottom-0 -right-1/4 w-1/2 h-full bg-emerald-500 blur-[160px] rounded-full"></div>
          </div>
          
          <div className="bg-white rounded-[48px] w-full max-w-xl p-12 space-y-12 relative z-10 shadow-2xl animate-in zoom-in-95 duration-500">
            <div className="text-center space-y-4">
              <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center text-white text-4xl font-black mx-auto shadow-2xl shadow-indigo-200 rotate-3">N</div>
              <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t('welcomeBack')}</h2>
              <p className="text-slate-500 font-medium">{t('setupMessage')}</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {SUPPORTED_LANGUAGES.map(lang => (
                <button
                  key={lang.name}
                  onClick={() => handleInitializeUI(lang.name)}
                  className="group flex items-center justify-between px-6 py-5 rounded-2xl border-2 border-slate-50 hover:border-indigo-600 hover:bg-indigo-50/30 transition-all duration-300"
                >
                  <div className="flex flex-col items-start">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-indigo-400 transition-colors">{lang.name}</span>
                    <span className="text-lg font-bold text-slate-700 group-hover:text-slate-900">{lang.label}</span>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-slate-50 group-hover:bg-indigo-600 flex items-center justify-center group-hover:text-white transition-all">
                     <Check size={16} />
                  </div>
                </button>
              ))}
            </div>
            
            <div className="text-center text-[10px] font-black uppercase tracking-[0.4em] text-slate-300">
              NowElla Workspace Intelligence
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
