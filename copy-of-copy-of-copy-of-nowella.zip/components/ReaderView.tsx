
import React from 'react';
import { ProjectState, BinderItem } from '../types';
import { Heart, Eye, MessageCircle, Share2, Plus, ArrowLeft } from 'lucide-react';

interface ReaderViewProps {
  project: ProjectState;
  onBack: () => void;
  t: (key: string) => string;
}

const ReaderView: React.FC<ReaderViewProps> = ({ project, onBack, t }) => {
  // Flatten all documents for reading
  const getAllDocuments = (items: BinderItem[]): BinderItem[] => {
    let docs: BinderItem[] = [];
    items.forEach(item => {
      if (item.type === 'document' && item.content) docs.push(item);
      if (item.children) docs = [...docs, ...getAllDocuments(item.children)];
    });
    return docs;
  };

  const storyContent = getAllDocuments(project.binder);

  return (
    <div className="h-full w-full bg-white overflow-y-auto fade-in">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-100 flex items-center justify-between px-6 py-4">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition">
            <ArrowLeft size={20} className="text-slate-600" />
          </button>
          <div>
            <h1 className="text-sm font-bold text-slate-800 line-clamp-1">{project.name}</h1>
            <p className="text-[10px] text-orange-600 font-black uppercase tracking-widest">{t('readerPreview')}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 bg-orange-500 text-white rounded-full text-xs font-bold shadow-lg shadow-orange-100 flex items-center gap-2">
            <Plus size={14} /> {t('library')}
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-6 py-12 space-y-20">
        {/* Cover Section */}
        <div className="flex flex-col items-center text-center space-y-6">
          <div className="w-64 h-96 rounded-xl overflow-hidden shadow-2xl shadow-slate-200 border-4 border-white">
            <img 
              src={project.coverUrl || 'https://picsum.photos/seed/story/600/900'} 
              className="w-full h-full object-cover" 
              alt="Book Cover" 
            />
          </div>
          <div className="space-y-2">
            <h2 className="text-4xl font-black text-slate-800 tracking-tight">{project.name}</h2>
            <p className="text-lg text-slate-500 font-medium">by {project.authorName || 'Author'}</p>
          </div>
          
          <div className="flex items-center gap-8 py-4 px-8 bg-slate-50 rounded-2xl border border-slate-100">
             <div className="flex flex-col items-center">
                <div className="flex items-center gap-1.5 text-slate-700 font-bold mb-0.5">
                   <Eye size={16} className="text-slate-400" /> {project.socialMetrics?.totalReads.toLocaleString()}
                </div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{t('reads')}</span>
             </div>
             <div className="flex flex-col items-center border-x border-slate-200 px-8">
                <div className="flex items-center gap-1.5 text-slate-700 font-bold mb-0.5">
                   <Heart size={16} className="text-orange-500" /> {project.socialMetrics?.totalVotes.toLocaleString()}
                </div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{t('votes')}</span>
             </div>
             <div className="flex flex-col items-center">
                <div className="flex items-center gap-1.5 text-slate-700 font-bold mb-0.5">
                   <MessageCircle size={16} className="text-slate-400" /> {storyContent.length}
                </div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{t('parts')}</span>
             </div>
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            {project.tags?.map(tag => (
              <span key={tag} className="px-4 py-1.5 bg-white border border-slate-200 rounded-full text-[11px] font-bold text-slate-600 hover:border-orange-500 hover:text-orange-600 cursor-pointer transition">
                #{tag}
              </span>
            ))}
          </div>
        </div>

        {/* Content Section */}
        <div className="space-y-32">
          {storyContent.map((part, idx) => (
            <section key={part.id} className="space-y-12 animate-in fade-in duration-700">
               <div className="space-y-4 border-b border-slate-50 pb-8">
                  <span className="text-orange-600 font-black uppercase text-[10px] tracking-widest">{t('part')} {idx + 1}</span>
                  <h3 className="text-3xl font-black text-slate-800">{part.title}</h3>
                  <div className="flex items-center gap-4 text-slate-400">
                    <div className="flex items-center gap-1.5 text-[11px] font-bold">
                       <Eye size={14} /> {part.socialStats?.reads || 0}
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] font-bold">
                       <Heart size={14} /> {part.socialStats?.votes || 0}
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] font-bold">
                       <MessageCircle size={14} /> {part.socialStats?.commentsCount || 0}
                    </div>
                  </div>
               </div>
               
               <div 
                 className="reader-content serif text-xl leading-[1.8] text-slate-700 space-y-8"
                 dangerouslySetInnerHTML={{ __html: part.content }}
               />

               <div className="flex items-center justify-center gap-4 py-12 border-t border-slate-50">
                  <button className="flex items-center gap-2 px-6 py-3 bg-slate-100 hover:bg-orange-50 hover:text-orange-600 rounded-full text-xs font-black uppercase transition group">
                    <Heart size={16} className="group-hover:scale-125 transition" /> {t('voteForPart')}
                  </button>
                  <button className="p-3 bg-slate-100 hover:bg-slate-200 rounded-full transition">
                    <Share2 size={16} className="text-slate-600" />
                  </button>
               </div>
            </section>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ReaderView;
