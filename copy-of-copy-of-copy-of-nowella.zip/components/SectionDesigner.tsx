
import React from 'react';
import { BinderItem } from '../types';
import { LayoutGrid, List, Target, Flame, Clock, Plus, ChevronRight, FileText, BarChart2, Activity } from 'lucide-react';

interface SectionDesignerProps {
  folder: BinderItem;
  onSelectScene: (id: string) => void;
  onAddScene: (parentId: string) => void;
  t: (key: string) => string;
}

const SectionDesigner: React.FC<SectionDesignerProps> = ({ folder, onSelectScene, onAddScene, t }) => {
  const scenes = folder.children || [];
  const totalWords = scenes.reduce((acc, scene) => {
    return acc + (scene.content || '').replace(/<[^>]*>/g, '').split(/\s+/).filter(x => x.length > 0).length;
  }, 0);

  const tensionPoints = scenes.map(s => s.yWriterData?.tension || 5);

  return (
    <div className="h-full flex flex-col bg-slate-50 overflow-y-auto animate-in fade-in duration-500 pb-20">
      <div className="max-w-6xl mx-auto w-full p-6 md:p-10 space-y-8">
        
        <div className="bg-white rounded-[32px] p-8 md:p-10 border border-slate-200 shadow-sm space-y-8 relative overflow-hidden transition-all hover:shadow-md">
          <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none">
            <BarChart2 size={240} />
          </div>
          
          <div className="flex flex-col md:flex-row justify-between items-start gap-6 relative z-10">
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-indigo-600">
                <div className="p-2 bg-indigo-50 rounded-xl">
                    <LayoutGrid size={20} />
                </div>
                <span className="text-[10px] font-black uppercase tracking-[0.2em]">{t('sectionStrategyNode')}</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-black text-slate-800 tracking-tight leading-tight">{folder.title}</h1>
              <div className="flex flex-wrap gap-2">
                 <span className="px-3 py-1 bg-slate-100 rounded-full text-[10px] font-bold text-slate-500 uppercase tracking-widest">{scenes.length} {t('parts')}</span>
                 <span className="px-3 py-1 bg-indigo-100 rounded-full text-[10px] font-bold text-indigo-600 uppercase tracking-widest">{t('activeDraft')}</span>
              </div>
            </div>
            
            <div className="flex gap-4">
                <div className="bg-slate-50 px-6 py-4 rounded-3xl border border-slate-100 flex flex-col items-center justify-center min-w-[140px]">
                  <div className="text-2xl font-black text-slate-800">{totalWords.toLocaleString()}</div>
                  <div className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{t('sectionWordCount')}</div>
                </div>
                <div className="bg-indigo-600 px-6 py-4 rounded-3xl border border-indigo-500 shadow-xl shadow-indigo-100 flex flex-col items-center justify-center min-w-[140px] text-white">
                  <div className="text-2xl font-black">{Math.ceil(totalWords / 200)}</div>
                  <div className="text-[9px] font-bold opacity-70 uppercase tracking-widest">{t('minReadingTime')}</div>
                </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-slate-100">
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-indigo-600">
                <Target size={16} />
                <span className="text-[10px] font-black uppercase tracking-widest">{t('narrativeObjective')}</span>
              </div>
              <textarea 
                placeholder={t('narrativeObjective')}
                className="w-full bg-slate-50 border border-slate-100 rounded-2xl p-4 text-xs text-slate-600 font-medium leading-relaxed focus:ring-2 focus:ring-indigo-500 focus:outline-none min-h-[100px] resize-none transition-all"
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-rose-600">
                <Activity size={16} />
                <span className="text-[10px] font-black uppercase tracking-widest">{t('intensityArc')}</span>
              </div>
              <div className="h-[100px] bg-slate-50 rounded-2xl border border-slate-100 flex items-end justify-between p-4 gap-1">
                 {tensionPoints.length > 0 ? tensionPoints.map((val, i) => (
                    <div 
                        key={i} 
                        className="flex-1 bg-rose-400/30 rounded-t-md relative group hover:bg-rose-500 transition-all cursor-help" 
                        style={{ height: `${val * 10}%` }}
                    />
                 )) : (
                     <div className="w-full h-full flex items-center justify-center text-[10px] text-slate-300 font-bold uppercase italic">{t('aiIdle')}</div>
                 )}
              </div>
            </div>

            <div className="bg-emerald-50/50 p-6 rounded-[24px] border border-emerald-100 space-y-4">
              <div className="flex items-center gap-2 text-emerald-600">
                <Clock size={16} />
                <span className="text-[10px] font-black uppercase tracking-widest">{t('sectionHealth')}</span>
              </div>
              <div className="space-y-4">
                  <div className="space-y-1">
                      <div className="flex justify-between text-[10px] font-bold text-emerald-700">
                          <span>{t('progress')}</span>
                          <span>70%</span>
                      </div>
                      <div className="h-2 w-full bg-emerald-100 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500" style={{ width: '70%' }}></div>
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex justify-between items-center px-4">
            <h2 className="text-xs font-black text-slate-400 uppercase tracking-[0.25em] flex items-center gap-3">
              <List size={16} /> {t('sequenceMap')}
            </h2>
            <button 
              onClick={() => onAddScene(folder.id)}
              className="group flex items-center gap-3 px-6 py-3 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 transition shadow-xl shadow-slate-200"
            >
              <Plus size={16} className="group-hover:rotate-90 transition-transform duration-300" /> {t('newNarrativeScene')}
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {scenes.map((scene, idx) => (
              <div 
                key={scene.id}
                onClick={() => onSelectScene(scene.id)}
                className="bg-white group border border-slate-200 rounded-[24px] p-6 flex items-center gap-6 hover:border-indigo-400 hover:shadow-2xl hover:-translate-y-1.5 transition-all duration-300 cursor-pointer"
              >
                <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 font-black text-xl group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300 shrink-0 shadow-inner">
                  {idx + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-slate-800 text-lg group-hover:text-indigo-600 transition-colors truncate">{scene.title}</h3>
                  </div>
                  <p className="text-xs text-slate-400 font-medium italic truncate">{scene.synopsis || "..."}</p>
                </div>
                <div className="p-3 bg-slate-50 rounded-xl text-slate-300 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                    <ChevronRight size={20} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SectionDesigner;
