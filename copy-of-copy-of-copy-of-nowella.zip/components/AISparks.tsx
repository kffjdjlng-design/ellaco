
import React, { useState } from 'react';
import { aiService } from '../geminiService';
import { Language } from '../types';
import { SUPPORTED_LANGUAGES } from '../constants';
import { 
  Sparkles, 
  RefreshCw, 
  Loader2, 
  BookOpen, 
  ShieldCheck, 
  Zap, 
  Target, 
  Feather,
  MessageCircle,
  HelpCircle,
  Search,
  Quote,
  Users,
  AlertCircle,
  CheckCircle,
  Globe,
  ShieldAlert,
  ChevronRight,
  Languages
} from 'lucide-react';

interface AISparksProps {
  context: string;
  language: Language;
  t: (key: string) => string;
}

const AISparks: React.FC<AISparksProps> = ({ context, language, t }) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [proReport, setProReport] = useState<any>(null);
  const [plagiarismData, setPlagiarismData] = useState<{ text: string; sources: string[] } | null>(null);
  const [activeTab, setActiveTab] = useState<'tools' | 'reports' | 'critique' | 'translate'>('tools');
  const [targetLanguage, setTargetLanguage] = useState<Language>('English');

  const handleSpark = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setResult(null);
    setAnalysis(null);
    setProReport(null);
    setPlagiarismData(null);
    try {
      const res = await aiService.getWritingSparks(context, prompt, language);
      setResult(res);
    } catch (e) {
      setResult("Error connecting to Gemini. Please check your API key.");
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyze = async () => {
    if (!context.trim()) return;
    setLoading(true);
    setResult(null);
    setAnalysis(null);
    setProReport(null);
    setPlagiarismData(null);
    try {
      const res = await aiService.analyzeStyle(context, language);
      setAnalysis(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleProReport = async (type: string) => {
    if (!context.trim()) return;
    setLoading(true);
    setResult(null);
    setAnalysis(null);
    setProReport(null);
    setPlagiarismData(null);
    try {
      const res = await aiService.getProWritingReport(context, type, language);
      setProReport(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handlePlagiarism = async () => {
    if (!context.trim()) return;
    setLoading(true);
    setResult(null);
    setAnalysis(null);
    setProReport(null);
    setPlagiarismData(null);
    try {
      const res = await aiService.checkPlagiarism(context, language);
      setPlagiarismData(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleTranslate = async () => {
    if (!context.trim()) return;
    setLoading(true);
    setResult(null);
    setAnalysis(null);
    setProReport(null);
    setPlagiarismData(null);
    try {
      const res = await aiService.translateText(context, targetLanguage, language);
      setResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="flex border-b border-slate-100">
        {(['tools', 'reports', 'critique', 'translate'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest transition ${
              activeTab === tab ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            {t(tab === 'critique' ? 'critiqueTab' : tab)}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {activeTab === 'tools' && (
          <div className="space-y-4">
            <div className="relative">
              <Sparkles className="absolute left-3 top-3 text-indigo-400" size={16} />
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={t('sparks')}
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-xs min-h-[100px] focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-all"
              />
            </div>
            <button
              onClick={handleSpark}
              disabled={loading}
              className="w-full py-3 bg-indigo-600 text-white rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-indigo-100 hover:scale-[1.02] active:scale-95 transition disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? <Loader2 className="animate-spin" size={14} /> : <Zap size={14} />}
              {t('generateSpark')}
            </button>
          </div>
        )}

        {activeTab === 'reports' && (
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'sticky', label: t('sticky'), icon: <Target size={14} /> },
              { id: 'overused', label: t('overused'), icon: <RefreshCw size={14} /> },
              { id: 'cliches', label: t('cliches'), icon: <Quote size={14} /> },
              { id: 'pacing', label: t('pacing'), icon: <Zap size={14} /> },
              { id: 'dialogue', label: t('dialogue'), icon: <MessageCircle size={14} /> },
              { id: 'grammar', label: t('grammar'), icon: <CheckCircle size={14} /> },
              { id: 'plagiarism', label: t('plagiarism'), icon: <ShieldAlert size={14} />, special: true }
            ].map(tool => (
              <button
                key={tool.id}
                onClick={() => tool.special ? handlePlagiarism() : handleProReport(tool.id)}
                disabled={loading}
                className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex flex-col items-center gap-2 hover:bg-indigo-50 hover:border-indigo-200 transition group disabled:opacity-50"
              >
                <div className="text-slate-400 group-hover:text-indigo-500">{tool.icon}</div>
                <span className="text-[10px] font-bold text-slate-600 text-center">{tool.label}</span>
              </button>
            ))}
          </div>
        )}

        {activeTab === 'critique' && (
          <div className="space-y-4">
             <button
              onClick={handleAnalyze}
              disabled={loading}
              className="w-full py-4 bg-slate-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-slate-800 transition shadow-lg shadow-slate-200"
            >
              {loading ? <Loader2 className="animate-spin" size={14} /> : <Feather size={14} />}
              {t('analyze')}
            </button>
            <button
              disabled={loading}
              className="w-full py-4 bg-white border border-slate-200 text-slate-600 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-slate-50 transition"
            >
              <Users size={14} />
              {t('critique')}
            </button>
          </div>
        )}

        {activeTab === 'translate' && (
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">{t('targetLanguage')}</label>
              <select 
                value={targetLanguage}
                onChange={(e) => setTargetLanguage(e.target.value as Language)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {SUPPORTED_LANGUAGES.map(lang => (
                  <option key={lang.name} value={lang.name}>{lang.label}</option>
                ))}
              </select>
            </div>
            <button
              onClick={handleTranslate}
              disabled={loading}
              className="w-full py-3 bg-indigo-600 text-white rounded-xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 transition disabled:opacity-50 shadow-lg shadow-indigo-100"
            >
              {loading ? <Loader2 className="animate-spin" size={14} /> : <Languages size={14} />}
              {t('translateManuscript')}
            </button>
          </div>
        )}

        {loading && (
          <div className="py-12 flex flex-col items-center justify-center text-slate-400 gap-4">
            <Loader2 className="animate-spin text-indigo-500" size={32} />
            <span className="text-xs font-bold uppercase tracking-widest animate-pulse text-indigo-600">{t('summoningAI')}</span>
          </div>
        )}

        {!loading && (result || analysis || proReport || plagiarismData) && (
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-4 fade-in">
            {result && (
              <div className="prose prose-slate prose-sm max-w-none">
                <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">{result}</div>
              </div>
            )}

            {analysis && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h5 className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">{t('styleScore')}</h5>
                  <span className="text-xl font-black text-slate-800">{analysis.readabilityScore}/100</span>
                </div>
                <div className="space-y-2">
                  <span className="text-[9px] font-bold text-slate-400 uppercase">{t('toneSentiment')}</span>
                  <div className="flex gap-2">
                    <span className="px-2 py-1 bg-white border border-slate-200 rounded text-[10px] font-bold text-slate-600">{analysis.tone}</span>
                    <span className="px-2 py-1 bg-white border border-slate-200 rounded text-[10px] font-bold text-slate-600">{analysis.sentiment}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <span className="text-[9px] font-bold text-slate-400 uppercase">{t('themes')}</span>
                  <div className="flex flex-wrap gap-1.5">
                    {analysis.keyThemes?.map((theme: string) => (
                      <span key={theme} className="px-2 py-1 bg-indigo-50 text-indigo-600 rounded text-[9px] font-black uppercase">{theme}</span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {proReport && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h5 className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">{t('efficiencyScore')}</h5>
                  <span className="text-xl font-black text-slate-800">{proReport.score}/100</span>
                </div>
                <p className="text-[10px] text-slate-500 italic leading-relaxed">"{proReport.summary}"</p>
                <div className="space-y-3">
                  {proReport.findings?.map((f: any, i: number) => (
                    <div key={i} className="bg-white p-3 rounded-xl border border-slate-100 space-y-2 shadow-sm">
                      <div className="text-[9px] font-bold text-rose-500 uppercase flex items-center gap-1"><AlertCircle size={10} /> {f.issue}</div>
                      <div className="text-[11px] text-slate-400 line-through">"{f.original}"</div>
                      <div className="text-[11px] text-slate-700 font-bold bg-emerald-50 p-2 rounded-lg border border-emerald-100 flex items-center gap-2">
                        <CheckCircle size={12} className="text-emerald-500" /> "{f.suggestion}"
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {plagiarismData && (
              <div className="space-y-4">
                 <div className="flex items-center gap-2 text-indigo-600">
                    <ShieldCheck size={16} />
                    <h5 className="text-[10px] font-black uppercase tracking-widest">{t('plagiarism')}</h5>
                 </div>
                 <p className="text-[11px] text-slate-600 leading-relaxed">{plagiarismData.text}</p>
                 {plagiarismData.sources.length > 0 && (
                   <div className="space-y-2">
                      <span className="text-[9px] font-bold text-slate-400 uppercase">{t('detectedSources')}</span>
                      <div className="space-y-1">
                        {plagiarismData.sources.map((url, i) => (
                          <a key={url} href={url} target="_blank" rel="noopener noreferrer" className="block text-[10px] text-indigo-500 hover:underline truncate">
                             {i + 1}. {url}
                          </a>
                        ))}
                      </div>
                   </div>
                 )}
              </div>
            )}
          </div>
        )}

        {!loading && !result && !analysis && !proReport && !plagiarismData && (
          <div className="py-20 text-center space-y-4">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-indigo-200">
              <Zap size={32} />
            </div>
            <div className="space-y-1">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{t('aiIdle')}</p>
              <p className="text-[10px] text-slate-400 italic px-8">{t('aiIdleDesc')}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AISparks;
