import React, { useState } from 'react';
import { ProjectState, BinderItem, BookTheme } from '../types';
import { BOOK_THEMES, ICONS } from '../constants';
// Fixed missing Palette icon import from lucide-react
import { Archive, Download, Eye, FileText, CheckCircle2, Settings, Type, Layout, ShieldCheck, Printer, FileDown, ArrowRight, Palette } from 'lucide-react';

interface ProductionHubProps {
  project: ProjectState;
  t: (key: string) => string;
}

const ProductionHub: React.FC<ProductionHubProps> = ({ project, t }) => {
  const [selectedFormat, setSelectedFormat] = useState<'pdf' | 'docx' | 'epub' | 'markdown'>('pdf');
  const [activeTheme, setActiveTheme] = useState<BookTheme>(project.settings.bookTheme);
  const [includeFrontMatter, setIncludeFrontMatter] = useState(true);
  const [includeBackMatter, setIncludeBackMatter] = useState(true);

  // Simple recursive check to get all document count
  const getDocCount = (items: BinderItem[]): number => {
    let count = 0;
    items.forEach(i => {
      if (i.type === 'document') count++;
      if (i.children) count += getDocCount(i.children);
    });
    return count;
  };

  const totalScenes = getDocCount(project.binder);

  return (
    <div className="h-full flex flex-col bg-slate-50 overflow-y-auto animate-in fade-in duration-500 pb-20">
      <div className="max-w-6xl mx-auto w-full p-6 md:p-10 space-y-8">
        
        <div className="flex flex-col md:flex-row justify-between items-start gap-6">
          <div className="space-y-1">
             <h2 className="text-3xl font-black text-slate-800 tracking-tight flex items-center gap-3">
                <Archive className="text-indigo-600" /> {t('compile')}
             </h2>
             <p className="text-slate-500 font-medium">{t('shareSubtitle')}</p>
          </div>
          <div className="flex gap-3">
             <button className="px-6 py-3 bg-white border border-slate-200 text-slate-600 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-slate-50 transition shadow-sm flex items-center gap-2">
                <Eye size={16} /> {t('readerPreview')}
             </button>
             <button className="px-8 py-3 bg-indigo-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-indigo-700 transition shadow-xl shadow-indigo-100 flex items-center gap-2">
                <Download size={16} /> {t('generate')}
             </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Configuration */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-[32px] p-8 border border-slate-200 shadow-sm space-y-8">
               <div className="space-y-6">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                    <Layout size={14} /> {t('manuscriptBlueprint')}
                  </h3>
                  <div className="space-y-3">
                     {project.binder.map(item => (
                       <div key={item.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-indigo-200 transition">
                          <div className="flex items-center gap-4">
                             <div className="text-slate-400">
                                {ICONS[item.type as keyof typeof ICONS] || <FileText size={18} />}
                             </div>
                             <div>
                                <p className="text-sm font-bold text-slate-700">{item.title}</p>
                                <p className="text-[10px] text-slate-400 font-bold uppercase">{item.children?.length || 0} {t('parts')}</p>
                             </div>
                          </div>
                          <div className="flex items-center gap-4">
                             <div className="w-10 h-6 bg-indigo-600 rounded-full flex items-center justify-end px-1 cursor-pointer">
                                <div className="w-4 h-4 bg-white rounded-full"></div>
                             </div>
                          </div>
                       </div>
                     ))}
                  </div>
               </div>

               <div className="space-y-6 pt-8 border-t border-slate-100">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                    <Palette size={14} /> {t('theme')}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {BOOK_THEMES.map(theme => (
                      <button
                        key={theme.id}
                        onClick={() => setActiveTheme(theme.id as any)}
                        className={`p-6 rounded-[24px] border-2 text-left transition-all ${
                          activeTheme === theme.id ? 'border-indigo-600 bg-indigo-50/30' : 'border-slate-100 hover:border-slate-200 bg-white'
                        }`}
                      >
                        <p className="text-sm font-black text-slate-800 mb-1" style={{ fontFamily: theme.font }}>{theme.id}</p>
                        <p className="text-[10px] text-slate-500 font-medium leading-relaxed">{theme.description}</p>
                      </button>
                    ))}
                  </div>
               </div>
            </div>
          </div>

          {/* Right: Export & Preview */}
          <div className="space-y-6">
             <div className="bg-slate-900 rounded-[32px] p-8 text-white space-y-6 shadow-2xl">
                <h3 className="text-[10px] font-black uppercase tracking-[0.2em] opacity-50 flex items-center gap-2">
                  <FileDown size={14} /> {t('generate')}
                </h3>
                <div className="grid grid-cols-2 gap-3">
                   {(['pdf', 'docx', 'epub', 'markdown'] as const).map(format => (
                     <button
                        key={format}
                        onClick={() => setSelectedFormat(format)}
                        className={`py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                          selectedFormat === format ? 'bg-white text-slate-900 border-white' : 'bg-transparent border-slate-700 text-slate-400 hover:border-slate-500'
                        }`}
                     >
                        {format}
                     </button>
                   ))}
                </div>
                <div className="pt-6 space-y-4">
                   <div className="flex justify-between text-xs font-bold">
                      <span className="opacity-50">{t('words')}</span>
                      <span>{totalScenes * 1200}</span> {/* Mock word count approx */}
                   </div>
                   <div className="flex justify-between text-xs font-bold">
                      <span className="opacity-50">Estimated Pages</span>
                      <span>{Math.ceil((totalScenes * 1200) / 300)}</span>
                   </div>
                   <div className="h-px bg-slate-800"></div>
                   <div className="flex items-center gap-3 text-emerald-400">
                      <ShieldCheck size={16} />
                      <span className="text-[10px] font-black uppercase tracking-widest">Ready for Production</span>
                   </div>
                </div>
             </div>

             <div className="bg-white rounded-[32px] p-8 border border-slate-200 shadow-sm space-y-4">
                <div className="w-full aspect-[3/4] bg-slate-100 rounded-2xl border border-slate-200 flex flex-col items-center justify-center text-slate-300 gap-4 overflow-hidden relative group">
                   <Printer size={48} className="opacity-20 group-hover:scale-110 transition-transform duration-500" />
                   <span className="text-[10px] font-black uppercase tracking-widest opacity-50">Draft Preview</span>
                   
                   {/* Realistic book page mockup effect */}
                   <div className="absolute inset-0 bg-white/0 group-hover:bg-white/90 transition-colors flex flex-col p-8 opacity-0 group-hover:opacity-100 overflow-hidden">
                      <p className="text-[8px] font-black text-indigo-600 uppercase tracking-[0.3em] mb-4">Chapter One</p>
                      <h4 className="text-lg font-black text-slate-800 mb-6" style={{ fontFamily: BOOK_THEMES.find(th => th.id === activeTheme)?.font }}>The Silent Horizon</h4>
                      <div className="space-y-2 opacity-60">
                        <div className="h-1 bg-slate-200 rounded-full w-full"></div>
                        <div className="h-1 bg-slate-200 rounded-full w-full"></div>
                        <div className="h-1 bg-slate-200 rounded-full w-5/6"></div>
                        <div className="h-1 bg-slate-200 rounded-full w-full"></div>
                        <div className="h-1 bg-slate-200 rounded-full w-4/6"></div>
                      </div>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductionHub;