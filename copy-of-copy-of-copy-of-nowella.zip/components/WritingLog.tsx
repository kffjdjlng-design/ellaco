
import React from 'react';
import { LogEntry } from '../types';
import { Calendar, Clock, Edit3, Plus, TrendingUp, BookOpen } from 'lucide-react';

interface WritingLogProps {
  logs: LogEntry[];
  t: (key: string) => string;
}

const WritingLog: React.FC<WritingLogProps> = ({ logs, t }) => {
  const sortedLogs = [...logs].sort((a, b) => b.timestamp - a.timestamp);
  const totalWords = logs.reduce((acc, log) => acc + log.wordsAdded, 0);
  const totalTime = logs.reduce((acc, log) => acc + log.sessionMinutes, 0);

  return (
    <div className="h-full bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col fade-in">
      <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">{t('workLog')}</h2>
          <p className="text-sm text-slate-500">{t('aiIdleDesc')}</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-indigo-100 hover:scale-105 transition active:scale-95">
           <Plus size={16} /> {t('newSession')}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-8">
        <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
           <div className="flex items-center gap-2 text-indigo-600 mb-2">
              <TrendingUp size={18} />
              <span className="text-[10px] font-black uppercase tracking-widest">{t('lifeTimeWords')}</span>
           </div>
           <div className="text-3xl font-black text-indigo-900">{totalWords.toLocaleString()}</div>
        </div>
        <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-100">
           <div className="flex items-center gap-2 text-emerald-600 mb-2">
              <Clock size={18} />
              <span className="text-[10px] font-black uppercase tracking-widest">{t('writingTime')}</span>
           </div>
           <div className="text-3xl font-black text-emerald-900">{Math.floor(totalTime / 60)}h {totalTime % 60}m</div>
        </div>
        <div className="bg-amber-50 p-6 rounded-2xl border border-amber-100">
           <div className="flex items-center gap-2 text-amber-600 mb-2">
              <BookOpen size={18} />
              <span className="text-[10px] font-black uppercase tracking-widest">{t('avgVelocity')}</span>
           </div>
           <div className="text-3xl font-black text-amber-900">{logs.length > 0 ? Math.round(totalWords / logs.length) : 0} <span className="text-lg">w/s</span></div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-8 pb-8">
        <div className="space-y-4">
           <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('sessionHistory')}</h4>
           {sortedLogs.map(log => (
             <div key={log.id} className="bg-white border border-slate-100 p-6 rounded-2xl flex items-center justify-between hover:border-indigo-200 hover:shadow-md transition">
                <div className="flex items-center gap-6">
                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex flex-col items-center justify-center text-slate-400 border border-slate-100">
                        <Calendar size={18} />
                    </div>
                    <div>
                        <div className="text-sm font-bold text-slate-800">{new Date(log.timestamp).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase">{log.sessionMinutes} {t('minReadingTime')}</div>
                    </div>
                </div>
                <div className="flex-1 px-12">
                   <p className="text-xs text-slate-500 italic leading-relaxed">"{log.note || t('aiIdleDesc')}"</p>
                </div>
                <div className="flex items-center gap-4 text-right">
                    <div>
                        <div className="text-xl font-black text-indigo-600">+{log.wordsAdded}</div>
                        <div className="text-[9px] font-black text-slate-300 uppercase">{t('words')}</div>
                    </div>
                    <button className="p-2 text-slate-200 hover:text-indigo-500 transition"><Edit3 size={16} /></button>
                </div>
             </div>
           ))}
        </div>
      </div>
    </div>
  );
};

export default WritingLog;
