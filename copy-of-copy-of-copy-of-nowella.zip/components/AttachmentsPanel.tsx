
import React from 'react';
import { BinderItem, Attachment } from '../types';
import { Paperclip, Image as ImageIcon, FileText, Plus, Trash2, ExternalLink } from 'lucide-react';

interface AttachmentsPanelProps {
  item: BinderItem;
  onUpdate: (attachments: Attachment[]) => void;
  t: (key: string) => string;
}

const AttachmentsPanel: React.FC<AttachmentsPanelProps> = ({ item, onUpdate, t }) => {
  const attachments = item.attachments || [];

  const addAttachment = (type: Attachment['type']) => {
      const newAtt: Attachment = {
          id: `att-${Date.now()}`,
          name: `New ${type.charAt(0).toUpperCase() + type.slice(1)}`,
          type,
          url: '#'
      };
      onUpdate([...attachments, newAtt]);
  };

  const removeAttachment = (id: string) => {
      onUpdate(attachments.filter(a => a.id !== id));
  };

  return (
    <div className="p-5 space-y-6 animate-in fade-in duration-300">
      <div className="flex justify-between items-center">
        <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
            <Paperclip size={12} /> {t('attachments')}
        </h4>
        <div className="flex gap-1">
            <button onClick={() => addAttachment('image')} className="p-1.5 bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition" title={t('cover')}>
                <ImageIcon size={14} />
            </button>
            <button onClick={() => addAttachment('note')} className="p-1.5 bg-slate-50 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition" title={t('newScene')}>
                <Plus size={14} />
            </button>
        </div>
      </div>

      {attachments.length > 0 ? (
          <div className="space-y-3">
              {attachments.map(att => (
                  <div key={att.id} className="p-3 bg-slate-50 border border-slate-100 rounded-xl group hover:border-indigo-200 transition">
                      <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                              {att.type === 'image' ? <ImageIcon size={14} className="text-emerald-500" /> : <FileText size={14} className="text-indigo-500" />}
                              <span className="text-[11px] font-bold text-slate-700">{att.name}</span>
                          </div>
                          <button onClick={() => removeAttachment(att.id)} className="text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition">
                              <Trash2 size={12} />
                          </button>
                      </div>
                      <div className="flex gap-2">
                          <button className="text-[9px] font-bold text-indigo-500 hover:underline flex items-center gap-1">
                              <ExternalLink size={8} /> {t('view')}
                          </button>
                          <button className="text-[9px] font-bold text-slate-400 hover:underline">{t('rename')}</button>
                      </div>
                  </div>
              ))}
          </div>
      ) : (
          <div className="py-20 text-center space-y-3">
              <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-200">
                <Paperclip size={20} />
              </div>
              <p className="text-xs text-slate-400 italic px-4">{t('attachmentPlaceholder')}</p>
          </div>
      )}
    </div>
  );
};

export default AttachmentsPanel;
