
import React, { useState } from 'react';
import { BinderItem, CharacterProfile, StoryItem, Storyline } from '../types';
import { Target, Tag, Users, Info, Flame, Clock, GitBranch, Heart, Eye, Package } from 'lucide-react';

interface InspectorPanelProps {
  item: BinderItem;
  characters: CharacterProfile[];
  storyItems: StoryItem[];
  storylines?: Storyline[];
  onUpdate: (updates: Partial<BinderItem>) => void;
  t: (key: string) => string;
}

const InspectorPanel: React.FC<InspectorPanelProps> = ({ item, characters, storyItems, storylines = [], onUpdate, t }) => {
  const [newTag, setNewTag] = useState('');
  
  const yData = item.yWriterData || {};
  const social = item.socialStats || { votes: 0, reads: 0, commentsCount: 0 };

  const updateYData = (updates: any) => {
      onUpdate({ yWriterData: { ...yData, ...updates } });
  };

  const updateSocial = (updates: any) => {
      onUpdate({ socialStats: { ...social, ...updates } });
  };

  return (
    <div className="p-5 space-y-8 animate-in fade-in duration-300 pb-20">
      {/* Social Engagement */}
      <div className="space-y-4">
        <h4 className="text-[10px] font-bold text-orange-500 uppercase tracking-widest flex items-center gap-2">
          <Heart size={12} /> {t('socialMetrics')}
        </h4>
        <div className="grid grid-cols-2 gap-3 bg-orange-50/50 p-4 rounded-xl border border-orange-100">
             <div className="space-y-1">
                <label className="text-[9px] font-bold text-orange-400 uppercase flex items-center gap-1"><Eye size={10} /> {t('reads')}</label>
                <input 
                    type="number" 
                    value={social.reads}
                    onChange={(e) => updateSocial({ reads: parseInt(e.target.value) })}
                    className="w-full bg-white border border-orange-200 rounded-lg text-xs p-2 focus:ring-1 focus:ring-orange-500"
                />
            </div>
            <div className="space-y-1">
                <label className="text-[9px] font-bold text-orange-400 uppercase flex items-center gap-1"><Heart size={10} /> {t('votes')}</label>
                <input 
                    type="number" 
                    value={social.votes}
                    onChange={(e) => updateSocial({ votes: parseInt(e.target.value) })}
                    className="w-full bg-white border border-orange-200 rounded-lg text-xs p-2 focus:ring-1 focus:ring-orange-500"
                />
            </div>
        </div>
      </div>

      {/* Synopsis & Narrative */}
      <div className="space-y-4">
        <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <Info size={12} /> {t('narrative')}
        </h4>
        <textarea 
          value={item.synopsis || ''}
          onChange={(e) => onUpdate({ synopsis: e.target.value })}
          placeholder={t('narrativeObjective')}
          className="w-full bg-slate-50 border border-slate-100 rounded-xl p-3 text-xs text-slate-600 focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none h-20"
        />
        <div className="grid grid-cols-1 gap-3">
            <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase">{t('conflict')}</label>
                <textarea 
                    value={yData.conflict || ''}
                    onChange={(e) => updateYData({ conflict: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl p-3 text-xs text-slate-600 focus:ring-1 focus:ring-indigo-500 h-16 resize-none"
                />
            </div>
            <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase">{t('outcome')}</label>
                <textarea 
                    value={yData.outcome || ''}
                    onChange={(e) => updateYData({ outcome: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl p-3 text-xs text-slate-600 focus:ring-1 focus:ring-indigo-500 h-16 resize-none"
                />
            </div>
        </div>
      </div>

      {/* Ratings */}
      <div className="space-y-4">
        <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <Flame size={12} /> {t('sparks')}
        </h4>
        <div className="space-y-4 bg-slate-50 p-4 rounded-xl">
            {[
                { label: t('tension'), key: 'tension', icon: <Flame size={12} className="text-rose-500" /> },
                { label: t('humor'), key: 'humor', icon: <Tag size={12} className="text-amber-500" /> },
                { label: t('importance'), key: 'importance', icon: <Target size={12} className="text-indigo-500" /> },
                { label: t('quality'), key: 'quality', icon: <Info size={12} className="text-emerald-500" /> }
            ].map(rating => (
                <div key={rating.key} className="space-y-1">
                    <div className="flex justify-between items-center">
                        <span className="text-[10px] font-bold text-slate-500 flex items-center gap-1">
                            {rating.icon} {rating.label}
                        </span>
                        <span className="text-[10px] font-black text-indigo-600">{(yData as any)[rating.key] || 5}/10</span>
                    </div>
                    <input 
                        type="range" min="1" max="10" 
                        value={(yData as any)[rating.key] || 5}
                        onChange={(e) => updateYData({ [rating.key]: parseInt(e.target.value) })}
                        className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                    />
                </div>
            ))}
        </div>
      </div>

      {/* Plot Architecture */}
      <div className="space-y-4">
        <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <GitBranch size={12} /> {t('plotThread')}
        </h4>
        <div className="space-y-2">
            <select 
                value={yData.storylineId || ''}
                onChange={(e) => updateYData({ storylineId: e.target.value })}
                className="w-full bg-slate-50 border border-slate-100 rounded-xl py-2 px-3 text-xs text-slate-700 focus:ring-2 focus:ring-indigo-500"
            >
                <option value="">{t('aiIdle')}</option>
                {storylines.map(sl => (
                    <option key={sl.id} value={sl.id}>{sl.name}</option>
                ))}
            </select>
            {yData.storylineId && (
                <div className="flex items-center gap-2 px-3 py-1 bg-indigo-50 rounded-lg">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: storylines.find(s => s.id === yData.storylineId)?.color }}></div>
                    <span className="text-[9px] font-black text-indigo-700 uppercase">{t('activeDraft')}</span>
                </div>
            )}
        </div>
      </div>

      {/* Timeline Section */}
      <div className="space-y-4">
        <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <Clock size={12} /> {t('timeDay')}
        </h4>
        <div className="grid grid-cols-2 gap-3">
             <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase">{t('part')} #</label>
                <input 
                    type="number" 
                    value={yData.inStoryDay || 1}
                    onChange={(e) => updateYData({ inStoryDay: parseInt(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-100 rounded-lg text-xs p-2 focus:ring-1 focus:ring-indigo-500"
                />
            </div>
            <div className="space-y-1">
                <label className="text-[9px] font-bold text-slate-400 uppercase">{t('write')}</label>
                <input 
                    type="text" 
                    value={yData.timeOfDay || '12:00'}
                    onChange={(e) => updateYData({ timeOfDay: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-100 rounded-lg text-xs p-2 focus:ring-1 focus:ring-indigo-500"
                    placeholder="e.g. Dawn"
                />
            </div>
        </div>
      </div>

      {/* Links */}
      <div className="space-y-6">
        <div className="space-y-2">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Users size={12} /> {t('cast')}
            </h4>
            <div className="flex flex-wrap gap-1.5">
                {characters.map(char => {
                    const isLinked = item.metadata?.linkedCharacters?.includes(char.id);
                    return (
                        <button 
                            key={char.id}
                            onClick={() => {
                                const current = item.metadata?.linkedCharacters || [];
                                const next = isLinked ? current.filter(id => id !== char.id) : [...current, char.id];
                                onUpdate({ metadata: { ...item.metadata, linkedCharacters: next } });
                            }}
                            className={`px-2 py-1 rounded-md text-[10px] font-bold transition ${isLinked ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                        >
                            {char.name}
                        </button>
                    )
                })}
            </div>
        </div>

        <div className="space-y-2">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Package size={12} /> {t('items')}
            </h4>
            <div className="flex flex-wrap gap-1.5">
                {storyItems.map(si => {
                    const isLinked = item.metadata?.linkedItems?.includes(si.id);
                    return (
                        <button 
                            key={si.id}
                            onClick={() => {
                                const current = item.metadata?.linkedItems || [];
                                const next = isLinked ? current.filter(id => id !== si.id) : [...current, si.id];
                                onUpdate({ metadata: { ...item.metadata, linkedItems: next } });
                            }}
                            className={`px-2 py-1 rounded-md text-[10px] font-bold transition ${isLinked ? 'bg-amber-600 text-white shadow-md' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                        >
                            {si.name}
                        </button>
                    )
                })}
            </div>
        </div>
      </div>
    </div>
  );
};

export default InspectorPanel;
