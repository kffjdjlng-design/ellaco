
import React, { useState } from 'react';
import { aiService } from '../geminiService';
import { Language } from '../types';
import { Search, Globe, Link2, BookOpen, Loader2, Sparkles, ChevronRight, ExternalLink, ArrowRight } from 'lucide-react';

interface ResearchLabProps {
  language: Language;
  t: (key: string) => string;
}

const ResearchLab: React.FC<ResearchLabProps> = ({ language, t }) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [researchData, setResearchData] = useState<{ answer: string; sources: { title: string; url: string }[] } | null>(null);

  const handleResearch = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    setResearchData(null);
    try {
      const data = await aiService.conductResearch(query, language);
      setResearchData(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-slate-50 overflow-hidden fade-in">
      <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full p-8 space-y-8 overflow-y-auto custom-scrollbar">
        {/* Hero / Search Section */}
        {!researchData && !loading && (
          <div className="flex-1 flex flex-col items-center justify-center space-y-8 py-20">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-indigo-600 text-white rounded-[24px] flex items-center justify-center mx-auto shadow-2xl shadow-indigo-100">
                <Search size={32} />
              </div>
              <h2 className="text-4xl font-black text-slate-800 tracking-tight">{t('researchIntelligence')}</h2>
              <p className="text-slate-500 font-medium max-w-md mx-auto">{t('researchSubtitle')}</p>
            </div>
            
            <form onSubmit={handleResearch} className="w-full relative group">
              <input 
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t('askAnything')}
                className="w-full bg-white border-2 border-slate-200 rounded-[32px] px-8 py-6 text-lg focus:outline-none focus:border-indigo-500 shadow-sm transition-all pr-20 group-hover:shadow-xl"
              />
              <button 
                type="submit"
                className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-indigo-600 text-white rounded-full flex items-center justify-center hover:scale-110 transition shadow-lg shadow-indigo-100"
              >
                <ArrowRight size={24} />
              </button>
            </form>

            <div className="flex flex-wrap justify-center gap-3">
              {['Paris fashion in 1920s', 'How FTL travel works in physics', 'Mesoamerican mythology basics', 'Types of sword steel'].map(suggestion => (
                <button 
                  key={suggestion}
                  onClick={() => { setQuery(suggestion); setTimeout(handleResearch, 100); }}
                  className="px-4 py-2 bg-white border border-slate-200 rounded-full text-xs font-bold text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200 transition"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="flex-1 flex flex-col items-center justify-center space-y-6">
            <div className="relative">
              <Loader2 size={64} className="text-indigo-600 animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Globe size={24} className="text-indigo-400" />
              </div>
            </div>
            <div className="text-center space-y-1">
              <p className="text-sm font-black text-indigo-600 uppercase tracking-widest animate-pulse">{t('scanningWeb')}</p>
              <p className="text-xs text-slate-400 font-medium italic">{t('groundingSources')}</p>
            </div>
          </div>
        )}

        {/* Results Section */}
        {researchData && !loading && (
          <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
            {/* New Search Bar (Sticky at top) */}
            <div className="sticky top-0 z-10 bg-slate-50/80 backdrop-blur-md py-4">
              <form onSubmit={handleResearch} className="relative group">
                <input 
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-full px-6 py-3 text-sm focus:outline-none focus:border-indigo-500 shadow-sm transition-all pr-12"
                />
                <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 text-indigo-600"><Search size={18} /></button>
              </form>
            </div>

            {/* Answer Content */}
            <div className="space-y-6">
              <div className="flex items-center gap-3 text-indigo-600">
                <Sparkles size={20} />
                <h3 className="text-xl font-black uppercase tracking-tight">{t('intelReport')}</h3>
              </div>
              <div className="bg-white rounded-[32px] p-10 border border-slate-200 shadow-sm prose prose-slate max-w-none">
                 <div className="text-slate-700 leading-[1.8] text-lg space-y-6 whitespace-pre-wrap">
                    {researchData.answer}
                 </div>
              </div>
            </div>

            {/* Sources Section */}
            {researchData.sources.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-slate-400">
                  <Link2 size={18} />
                  <h4 className="text-[10px] font-black uppercase tracking-widest">{t('verifiedSources')}</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {researchData.sources.map((source, idx) => (
                    <a 
                      key={idx} 
                      href={source.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="group flex items-center justify-between p-4 bg-white border border-slate-200 rounded-2xl hover:border-indigo-400 transition shadow-sm"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-8 h-8 bg-slate-50 rounded-lg flex items-center justify-center shrink-0 group-hover:bg-indigo-50 transition">
                           <Globe size={14} className="text-slate-400 group-hover:text-indigo-500" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-[11px] font-bold text-slate-800 truncate">{source.title}</p>
                          <p className="text-[9px] text-slate-400 truncate">{source.url}</p>
                        </div>
                      </div>
                      <ExternalLink size={14} className="text-slate-300 group-hover:text-indigo-600 shrink-0" />
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Related Actions */}
            <div className="flex gap-4 pt-8">
              <button className="flex-1 py-4 bg-indigo-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl shadow-indigo-100 flex items-center justify-center gap-2 hover:scale-[1.02] transition">
                <BookOpen size={16} /> {t('saveToResearch')}
              </button>
              <button className="flex-1 py-4 bg-white border border-slate-200 text-slate-600 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-slate-50 transition">
                <ChevronRight size={16} /> {t('genSceneFromFact')}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResearchLab;
