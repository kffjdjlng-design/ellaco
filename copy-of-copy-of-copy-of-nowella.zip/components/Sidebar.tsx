
import React, { useState } from 'react';
import { BinderItem } from '../types';
import { ICONS } from '../constants';
import { PlusCircle, Search, MoreVertical, Trash2, FolderPlus, FilePlus, ChevronRight, ChevronDown } from 'lucide-react';

interface SidebarProps {
  binder: BinderItem[];
  activeId: string;
  onSelect: (id: string) => void;
  onAddItem: (parentId: string | null, type: 'folder' | 'document') => void;
  onDeleteItem: (id: string) => void;
  onOpenResearch?: () => void;
  onOpenBoards?: () => void;
  onOpenTemplates?: () => void;
  t: (key: string) => string;
}

const TreeItem: React.FC<{
  item: BinderItem;
  level: number;
  activeId: string;
  onSelect: (id: string) => void;
  onAddItem: (parentId: string, type: 'folder' | 'document') => void;
  onDeleteItem: (id: string) => void;
  t: (key: string) => string;
}> = ({ item, level, activeId, onSelect, onAddItem, onDeleteItem, t }) => {
  const [isOpen, setIsOpen] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  const isActive = activeId === item.id;
  const isFolder = ['folder', 'front-matter', 'back-matter'].includes(item.type);

  return (
    <div className="select-none relative">
      <div 
        onClick={() => {
          onSelect(item.id);
          if (isFolder) setIsOpen(!isOpen);
        }}
        className={`flex items-center py-2 px-3 cursor-pointer group rounded-xl transition-all ${
          isActive 
            ? 'bg-indigo-600 text-white shadow-lg' 
            : 'hover:bg-slate-100 text-slate-600'
        } ${isFolder && level === 0 ? 'mt-4 first:mt-0' : 'mt-1'}`}
        style={{ marginLeft: `${level * 12}px` }}
      >
        <div className={`mr-2 flex items-center justify-center w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`}>
          {isFolder ? (
            isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />
          ) : (
            ICONS[item.type as keyof typeof ICONS] || ICONS.document
          )}
        </div>
        
        <span className={`text-xs flex-1 truncate ${isActive || (isFolder && level === 0) ? 'font-bold' : 'font-medium'}`}>
          {isFolder && level === 0 ? item.title.toUpperCase() : item.title}
        </span>
        
        <button 
          onClick={(e) => { e.stopPropagation(); setShowMenu(!showMenu); }}
          className={`p-1 rounded hover:bg-black/10 transition ${isActive ? 'text-white' : 'text-slate-400 opacity-0 group-hover:opacity-100'}`}
        >
          <MoreVertical size={14} />
        </button>

        {showMenu && (
          <div className="absolute left-full top-0 ml-2 bg-white border border-slate-200 shadow-2xl rounded-xl p-1.5 z-[100] min-w-[160px] text-slate-700 font-bold text-[10px] uppercase tracking-widest animate-in fade-in zoom-in-95 duration-150">
            {isFolder && (
              <>
                <button onClick={(e) => { e.stopPropagation(); onAddItem(item.id, 'document'); setShowMenu(false); }} className="w-full flex items-center gap-2 px-3 py-2.5 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition-colors">
                  <FilePlus size={14} /> {t('newScene')}
                </button>
                <button onClick={(e) => { e.stopPropagation(); onAddItem(item.id, 'folder'); setShowMenu(false); }} className="w-full flex items-center gap-2 px-3 py-2.5 hover:bg-indigo-50 hover:text-indigo-600 rounded-lg transition-colors">
                  <FolderPlus size={14} /> {t('newSubSection')}
                </button>
                <div className="h-px bg-slate-100 my-1.5 mx-1"></div>
              </>
            )}
            <button onClick={(e) => { e.stopPropagation(); onDeleteItem(item.id); setShowMenu(false); }} className="w-full flex items-center gap-2 px-3 py-2.5 hover:bg-rose-50 text-rose-500 rounded-lg transition-colors">
              <Trash2 size={14} /> {t('deleteEntry')}
            </button>
          </div>
        )}
      </div>

      {isFolder && isOpen && item.children && (
        <div className="mt-0.5 border-l border-slate-100 ml-5">
          {item.children.map(child => (
            <TreeItem 
              key={child.id} 
              item={child} 
              level={level + 1} 
              activeId={activeId} 
              onSelect={onSelect} 
              onAddItem={onAddItem}
              onDeleteItem={onDeleteItem}
              t={t}
            />
          ))}
        </div>
      )}
      {showMenu && <div className="fixed inset-0 z-40 bg-black/5" onClick={() => setShowMenu(false)}></div>}
    </div>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ binder, activeId, onSelect, onAddItem, onDeleteItem, onOpenResearch, onOpenBoards, onOpenTemplates, t }) => {
  return (
    <aside className="w-72 border-r border-slate-200 bg-white flex flex-col shrink-0 transition-all duration-300">
      <div className="p-5 border-b border-slate-100 space-y-5">
        <div className="flex items-center justify-between">
            <h2 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.25em]">{t('binderTitle')}</h2>
            <div className="flex gap-1.5">
                <button onClick={() => onAddItem(null, 'folder')} className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 transition" title={t('newSubSection')}>
                    <FolderPlus size={18} />
                </button>
                <button onClick={() => onAddItem(null, 'document')} className="p-2 hover:bg-indigo-50 rounded-xl text-indigo-500 transition" title={t('newScene')}>
                    <PlusCircle size={18} />
                </button>
            </div>
        </div>
        
        <div className="relative group">
            <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" />
            <input 
                type="text" 
                placeholder={t('findInHierarchy')}
                className="w-full bg-slate-50 border border-slate-200 rounded-[14px] py-2.5 pl-10 pr-4 text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none focus:bg-white transition-all shadow-sm"
            />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-6 px-4 space-y-1 custom-scrollbar">
        {binder.map(item => (
          <TreeItem 
            key={item.id} 
            item={item} 
            level={0} 
            activeId={activeId} 
            onSelect={onSelect} 
            onAddItem={onAddItem}
            onDeleteItem={onDeleteItem}
            t={t}
          />
        ))}
      </div>

      <div className="p-5 border-t border-slate-100 space-y-2 bg-slate-50/30">
        <button onClick={onOpenTemplates} className="w-full flex items-center gap-3 px-4 py-3 text-[11px] font-bold text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 rounded-xl transition-all shadow-sm bg-white border border-slate-200">
          <ICONS.templates.type size={16} /> <span>{t('templates')}</span>
        </button>
        <button onClick={onOpenBoards} className="w-full flex items-center gap-3 px-4 py-3 text-[11px] font-bold text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 rounded-xl transition-all">
          <ICONS.boards.type size={16} /> <span>{t('boards')}</span>
        </button>
        <button onClick={onOpenResearch} className="w-full flex items-center gap-3 px-4 py-3 text-[11px] font-bold text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 rounded-xl transition-all">
          {ICONS.research} <span>{t('lab')}</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
