
import React from 'react';
import { ProjectState } from '../types';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { TrendingUp, Target, Calendar, Clock } from 'lucide-react';

interface StatsPanelProps {
  project: ProjectState;
  t: (key: string) => string;
}

const StatsPanel: React.FC<StatsPanelProps> = ({ project, t }) => {
  // Mock data for the chart
  const data = [
    { day: 'Mon', words: 400 },
    { day: 'Tue', words: 1200 },
    { day: 'Wed', words: 800 },
    { day: 'Thu', words: 1500 },
    { day: 'Fri', words: 900 },
    { day: 'Sat', words: 300 },
    { day: 'Sun', words: 1100 },
  ];

  const totalWords = project.binder.reduce((acc, item) => {
    const countWords = (i: any): number => {
      let count = (i.content || '').replace(/<[^>]*>/g, '').split(/\s+/).filter((x: string) => x.length > 0).length;
      if (i.children) count += i.children.reduce((c: any, child: any) => c + countWords(child), 0);
      return count;
    };
    return acc + countWords(item);
  }, 0);

  const progress = Math.round((totalWords / project.goals.totalWordGoal) * 100);

  // Goal Calculation
  const getDaysRemaining = () => {
    if (!project.goals.deadline) return 0;
    const deadline = new Date(project.goals.deadline);
    const today = new Date();
    const diffTime = Math.max(0, deadline.getTime() - today.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const daysLeft = getDaysRemaining();
  const wordsLeft = Math.max(0, project.goals.totalWordGoal - totalWords);
  const dailyTarget = daysLeft > 0 ? Math.ceil(wordsLeft / daysLeft) : 0;

  return (
    <div className="space-y-6">
      <div className="space-y-4">
         <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/50">
            <div className="flex items-center justify-between mb-2">
               <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('totalManuscriptProgress')}</span>
               <span className="text-xs font-bold text-indigo-600">{progress}%</span>
            </div>
            <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
               <div className="h-full bg-indigo-500 transition-all duration-1000" style={{ width: `${progress}%` }}></div>
            </div>
            <div className="mt-2 text-[10px] text-slate-500 flex justify-between">
               <span>{totalWords.toLocaleString()} {t('words')}</span>
               <span>Goal: {project.goals.totalWordGoal.toLocaleString()}</span>
            </div>
         </div>

         {/* Deadline Card */}
         <div className="bg-indigo-600 p-4 rounded-xl text-white shadow-xl shadow-indigo-100">
            <div className="flex items-center gap-2 mb-3">
               <Calendar size={14} className="opacity-60" />
               <span className="text-[10px] font-black uppercase tracking-widest">{t('deadlineInsight')}</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
               <div>
                  <div className="text-2xl font-black">{daysLeft}</div>
                  <div className="text-[9px] font-bold opacity-60 uppercase">{t('daysLeft')}</div>
               </div>
               <div>
                  <div className="text-2xl font-black">{dailyTarget}</div>
                  <div className="text-[9px] font-bold opacity-60 uppercase">{t('wordsPerDay')}</div>
               </div>
            </div>
            <p className="mt-3 text-[10px] opacity-80 leading-relaxed font-medium">
               {t('aiIdleDesc')}
            </p>
         </div>

         <div className="grid grid-cols-2 gap-3">
            <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-100">
               <div className="text-emerald-600 mb-1"><Target size={14} /></div>
               <div className="text-lg font-bold text-emerald-900 leading-none">1,240</div>
               <div className="text-[10px] font-bold text-emerald-700/60 uppercase">{t('part')}</div>
            </div>
            <div className="bg-amber-50 p-3 rounded-xl border border-amber-100">
               <div className="text-amber-600 mb-1"><TrendingUp size={14} /></div>
               <div className="text-lg font-bold text-amber-900 leading-none">8.4k</div>
               <div className="text-[10px] font-bold text-amber-700/60 uppercase">{t('progress')}</div>
            </div>
         </div>
      </div>

      <div className="space-y-3">
        <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
          <Clock size={12} /> {t('writingVelocity')}
        </h4>
        <div className="h-48 w-full bg-slate-50 rounded-xl p-2 border border-slate-200/50">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
              <Tooltip 
                cursor={{fill: 'rgba(99, 102, 241, 0.05)'}}
                contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '10px'}}
              />
              <Bar dataKey="words" radius={[4, 4, 0, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.words > 1000 ? '#6366f1' : '#cbd5e1'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default StatsPanel;
