
import React from 'react';
import { BinderItem } from '../types';
import { Edit3 } from 'lucide-react';

interface CorkboardProps {
  folder: BinderItem;
  onSelectItem: (id: string) => void;
  t: (key: string) => string;
}

const Corkboard: React.FC<CorkboardProps> = ({ folder, onSelectItem, t }) => {
  const cards = folder.children || [];

  return (
    <div className="p-4 h-full overflow-y-auto bg-slate-100 rounded-2xl border-4 border-slate-200 border-dashed">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {cards.map(card => (
          <div 
            key={card.id}
            onClick={() => onSelectItem(card.id)}
            className="bg-[#fff9e6] shadow-md border border-amber-200/50 min-h-[220px] p-6 flex flex-col cursor-pointer hover:shadow-xl hover:-translate-y-1 transition-all group relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-1 bg-amber-200"></div>
            <div className="flex justify-between items-start mb-3">
              <h3 className="font-bold text-amber-900 text-lg">{card.title}</h3>
              <Edit3 size={14} className="text-amber-400 opacity-0 group-hover:opacity-100 transition" />
            </div>
            <p className="text-amber-800/70 text-sm leading-relaxed flex-1 line-clamp-6">
              {card.synopsis || t('aiIdleDesc')}
            </p>
            <div className="mt-4 pt-3 border-t border-amber-200/40 flex justify-between items-center">
              <span className="text-[10px] font-bold uppercase tracking-widest text-amber-400">
                {card.metadata?.status || 'New'}
              </span>
              <span className="text-[10px] font-medium text-amber-400">
                {(card.content || '').replace(/<[^>]*>/g, '').split(/\s+/).filter(x => x.length > 0).length || 0} {t('words').toLowerCase()}
              </span>
            </div>
          </div>
        ))}
        
        {/* Add Card Placeholder */}
        <button className="border-2 border-dashed border-slate-300 rounded-lg flex flex-col items-center justify-center p-6 text-slate-400 hover:border-indigo-400 hover:text-indigo-500 transition-colors group">
          <div className="w-12 h-12 rounded-full border-2 border-dashed border-current flex items-center justify-center mb-2 group-hover:scale-110 transition">
            <span className="text-2xl font-light">+</span>
          </div>
          <span className="text-xs font-bold uppercase tracking-widest">{t('newScene')}</span>
        </button>
      </div>
    </div>
  );
};

export default Corkboard;
