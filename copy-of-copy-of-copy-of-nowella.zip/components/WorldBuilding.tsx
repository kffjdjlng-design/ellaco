
import React, { useState, useRef } from 'react';
import { ProjectState, LoreEntry, WorldMap, WorldMapPin, CharacterProfile } from '../types';
import { aiService } from '../geminiService';
import { Plus, Trash2, Globe, Map as MapIcon, Palette, BookMarked, Loader2, Sparkles, Image as ImageIcon, History, Shield, ArrowLeft } from 'lucide-react';

interface WorldBuildingProps {
  project: ProjectState;
  updateProject: (updates: Partial<ProjectState>) => void;
  t: (key: string) => string;
  onBackToStudio: () => void;
}

const LoreSection: React.FC<{
  lore: LoreEntry[];
  onAdd: () => void;
  onUpdate: (id: string, updates: Partial<LoreEntry>) => void;
  onDelete: (id: string) => void;
  t: (key: string) => string;
}> = ({ lore, onAdd, onUpdate, onDelete, t }) => {
  const categories: LoreEntry['category'][] = ['History', 'Factions', 'Magic', 'Technology', 'Culture', 'Other'];
  const [activeLoreId, setActiveLoreId] = useState<string | null>(lore[0]?.id || null);

  const activeEntry = lore.find(e => e.id === activeLoreId);

  return (
    <div className="flex h-full gap-6 fade-in">
      <div className="w-64 flex flex-col gap-4">
        <button 
          onClick={onAdd}
          className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-100 hover:scale-[1.02] transition active:scale-95"
        >
          <Plus size={16} /> {t('addLoreEntry')}
        </button>
        <div className="flex-1 overflow-y-auto pr-2 space-y-4">
          {categories.map(cat => (
            <div key={cat} className="space-y-1">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-2 mb-2 flex items-center gap-2">
                {cat === 'Factions' ? <Shield size={10} /> : cat === 'History' ? <History size={10} /> : <BookMarked size={10} />}
                {cat}
              </h4>
              {lore.filter(l => l.category === cat).map(entry => (
                <button
                  key={entry.id}
                  onClick={() => setActiveLoreId(entry.id)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs transition-all ${
                    activeLoreId === entry.id ? 'bg-indigo-50 text-indigo-700 font-bold border border-indigo-100 shadow-sm' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {entry.title || t('aiIdleDesc')}
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
        {activeEntry ? (
          <div className="flex-1 flex flex-col p-8 space-y-6 overflow-y-auto">
            <div className="flex justify-between items-start">
               <div className="space-y-1 flex-1">
                  <input 
                    type="text" 
                    value={activeEntry.title}
                    onChange={(e) => onUpdate(activeEntry.id, { title: e.target.value })}
                    className="text-3xl font-bold text-slate-800 bg-transparent border-none outline-none focus:ring-0 w-full"
                    placeholder={t('aiIdleDesc')}
                  />
                  <select 
                    value={activeEntry.category}
                    onChange={(e) => onUpdate(activeEntry.id, { category: e.target.value as LoreEntry['category'] })}
                    className="bg-slate-100 text-[10px] font-black text-slate-500 uppercase tracking-widest px-2 py-1 rounded-md border-none focus:ring-0"
                  >
                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
               </div>
               <button 
                onClick={() => onDelete(activeEntry.id)}
                className="p-2 text-slate-300 hover:text-rose-500 transition"
               >
                <Trash2 size={20} />
               </button>
            </div>
            <textarea 
              value={activeEntry.content}
              onChange={(e) => onUpdate(activeEntry.id, { content: e.target.value })}
              className="flex-1 bg-transparent border-none outline-none focus:ring-0 text-slate-600 leading-relaxed resize-none text-base"
              placeholder={t('lorePlaceholder')}
            />
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 p-8 text-center space-y-4">
             <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center">
                <BookMarked size={40} className="text-slate-200" />
             </div>
             <div>
                <p className="font-bold text-slate-600">{t('noLoreSelected')}</p>
                <p className="text-xs">{t('selectEntryStart')}</p>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

const MapCreator: React.FC<{
  maps: WorldMap[];
  onAdd: () => void;
  onUpdate: (id: string, updates: Partial<WorldMap>) => void;
  onDelete: (id: string) => void;
  t: (key: string) => string;
}> = ({ maps, onAdd, onUpdate, onDelete, t }) => {
  const [activeMapId, setActiveMapId] = useState<string | null>(maps[0]?.id || null);
  const mapRef = useRef<HTMLDivElement>(null);
  const activeMap = maps.find(m => m.id === activeMapId);

  const handleMapClick = (e: React.MouseEvent) => {
    if (!activeMap || !mapRef.current) return;
    const rect = mapRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    const newPin: WorldMapPin = {
      id: `pin-${Date.now()}`,
      x,
      y,
      title: t('newLocation'),
      description: t('describeLandmark')
    };

    onUpdate(activeMap.id, { pins: [...activeMap.pins, newPin] });
  };

  return (
    <div className="flex h-full gap-6 fade-in">
      <div className="w-64 flex flex-col gap-4">
        <button 
          onClick={onAdd}
          className="w-full flex items-center justify-center gap-2 py-3 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-100 hover:scale-[1.02] transition active:scale-95"
        >
          <Plus size={16} /> {t('createNewMap')}
        </button>
        <div className="flex-1 overflow-y-auto pr-2 space-y-2">
          {maps.map(map => (
            <button
              key={map.id}
              onClick={() => setActiveMapId(map.id)}
              className={`w-full text-left px-4 py-3 rounded-xl text-xs transition-all flex items-center gap-3 ${
                activeMapId === map.id ? 'bg-emerald-50 text-emerald-700 font-bold border border-emerald-100' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <MapIcon size={14} /> {map.name}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 bg-slate-200 rounded-3xl border border-slate-300 shadow-inner overflow-hidden relative flex items-center justify-center">
        {activeMap ? (
          <div className="relative w-full h-full group">
            <div 
              ref={mapRef}
              onClick={handleMapClick}
              className="w-full h-full bg-cover bg-center cursor-crosshair relative"
              style={{ backgroundImage: `url(${activeMap.imageUrl})` }}
            >
              {activeMap.pins.map(pin => (
                <div 
                  key={pin.id}
                  className="absolute w-6 h-6 -translate-x-1/2 -translate-y-1/2 bg-rose-600 border-4 border-white rounded-full shadow-lg cursor-pointer hover:scale-125 transition-transform"
                  style={{ left: `${pin.x}%`, top: `${pin.y}%` }}
                  title={pin.title}
                />
              ))}
            </div>
            <div className="absolute top-6 left-6 flex items-center gap-4 bg-white/90 backdrop-blur-md p-3 rounded-2xl border border-slate-200 shadow-xl opacity-0 group-hover:opacity-100 transition-opacity">
                <input 
                  value={activeMap.name}
                  onChange={(e) => onUpdate(activeMap.id, { name: e.target.value })}
                  className="bg-transparent border-none focus:ring-0 text-sm font-bold text-slate-800 p-0"
                />
                <button onClick={() => onDelete(activeMap.id)} className="text-slate-400 hover:text-rose-500 transition">
                  <Trash2 size={16} />
                </button>
            </div>
          </div>
        ) : (
          <div className="text-slate-400 font-bold uppercase tracking-widest">{t('mapPlaceholder')}</div>
        )}
      </div>
    </div>
  );
};

const Visualizer: React.FC<{
  characters: CharacterProfile[];
  onUpdateCharacter: (id: string, updates: Partial<CharacterProfile>) => void;
  t: (key: string) => string;
}> = ({ characters, onUpdateCharacter, t }) => {
  const [activeCharId, setActiveCharId] = useState<string | null>(characters[0]?.id || null);
  const [loading, setLoading] = useState(false);
  const activeChar = characters.find(c => c.id === activeCharId);

  const generatePortrait = async () => {
    if (!activeChar) return;
    setLoading(true);
    try {
      const prompt = `A professional character portrait of ${activeChar.name}. Role: ${activeChar.role}. Features: ${activeChar.description}. Personality traits: ${activeChar.traits.join(', ')}. Artistic style: Epic digital fantasy/sci-fi illustration.`;
      const imageUrl = await aiService.generateImage(prompt);
      onUpdateCharacter(activeChar.id, { imageUrl });
    } catch (e) {
      console.error(e);
      alert("Failed to generate image. Please check your API key.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-full gap-6 fade-in">
      <div className="w-64 flex flex-col gap-4">
        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-2">{t('selectCharacter')}</h4>
        <div className="flex-1 overflow-y-auto pr-2 space-y-1">
          {characters.map(char => (
            <button
              key={char.id}
              onClick={() => setActiveCharId(char.id)}
              className={`w-full text-left px-3 py-3 rounded-xl text-xs transition-all flex items-center gap-3 ${
                activeCharId === char.id ? 'bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-100' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <div className="w-6 h-6 rounded-full bg-slate-200 overflow-hidden shrink-0 border border-white/20">
                {char.imageUrl && <img src={char.imageUrl} className="w-full h-full object-cover" />}
              </div>
              <span className="truncate">{char.name}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
        {activeChar ? (
          <div className="flex-1 flex flex-col items-center justify-center p-12 space-y-8">
            <div className="relative group">
              <div className="w-80 h-80 rounded-[40px] bg-slate-100 overflow-hidden border-8 border-white shadow-2xl relative">
                {activeChar.imageUrl ? (
                  <img src={activeChar.imageUrl} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-300">
                    <ImageIcon size={64} className="opacity-20" />
                  </div>
                )}
                {loading && (
                  <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center text-indigo-600 gap-4">
                    <Loader2 size={48} className="animate-spin" />
                    <span className="text-xs font-black uppercase tracking-widest animate-pulse">{t('visualizing')}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="max-w-md text-center space-y-4">
              <h3 className="text-3xl font-black text-slate-800">{activeChar.name}</h3>
              <p className="text-sm text-slate-500 leading-relaxed italic">"{activeChar.description || t('aiIdleDesc')}"</p>
              
              <button 
                onClick={generatePortrait}
                disabled={loading}
                className="inline-flex items-center gap-3 px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-indigo-100 hover:scale-105 transition disabled:opacity-50"
              >
                <Sparkles size={16} /> {activeChar.imageUrl ? t('reVisualize') : t('visualizeCharacter')}
              </button>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
             <Palette size={48} className="mb-4 opacity-20" />
             <p className="text-xs font-bold uppercase tracking-widest">{t('selectCharToVis')}</p>
          </div>
        )}
      </div>
    </div>
  );
};

const WorldBuilding: React.FC<WorldBuildingProps> = ({ project, updateProject, t, onBackToStudio }) => {
  const [activeSubTab, setActiveSubTab] = useState<'lore' | 'maps' | 'visualizer'>('lore');

  const addLore = () => {
    const newLore: LoreEntry = {
      id: `lore-${Date.now()}`,
      category: 'Other',
      title: 'New Lore Entry',
      content: ''
    };
    updateProject({ 
      worldBuilding: { 
        ...project.worldBuilding, 
        lore: [newLore, ...project.worldBuilding.lore] 
      } 
    });
  };

  const updateLore = (id: string, updates: Partial<LoreEntry>) => {
    const updated = project.worldBuilding.lore.map(l => l.id === id ? { ...l, ...updates } : l);
    updateProject({ worldBuilding: { ...project.worldBuilding, lore: updated } });
  };

  const deleteLore = (id: string) => {
    const updated = project.worldBuilding.lore.filter(l => l.id !== id);
    updateProject({ worldBuilding: { ...project.worldBuilding, lore: updated } });
  };

  const addMap = () => {
    const newMap: WorldMap = {
      id: `map-${Date.now()}`,
      name: 'New Map',
      imageUrl: 'https://picsum.photos/seed/world/1200/800',
      pins: []
    };
    updateProject({ 
      worldBuilding: { 
        ...project.worldBuilding, 
        maps: [newMap, ...project.worldBuilding.maps] 
      } 
    });
  };

  const updateMap = (id: string, updates: Partial<WorldMap>) => {
    const updated = project.worldBuilding.maps.map(m => m.id === id ? { ...m, ...updates } : m);
    updateProject({ worldBuilding: { ...project.worldBuilding, maps: updated } });
  };

  const deleteMap = (id: string) => {
    const updated = project.worldBuilding.maps.filter(m => m.id !== id);
    updateProject({ worldBuilding: { ...project.worldBuilding, maps: updated } });
  };

  const updateCharacter = (id: string, updates: Partial<CharacterProfile>) => {
    const updated = project.characters.map(c => c.id === id ? { ...c, ...updates } : c);
    updateProject({ characters: updated });
  };

  return (
    <div className="h-full flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
           <button 
             onClick={onBackToStudio}
             className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition active:scale-95"
           >
              <ArrowLeft size={24} />
           </button>
           <div>
              <h2 className="text-2xl font-bold text-slate-800">{t('world')}</h2>
              <p className="text-xs text-slate-500 font-medium tracking-tight">{t('worldSubtitle')}</p>
           </div>
        </div>
        <div className="flex bg-slate-200/50 p-1 rounded-2xl">
           {[
             { id: 'lore', label: t('lore'), icon: <BookMarked size={14} /> },
             { id: 'maps', label: t('maps'), icon: <MapIcon size={14} /> },
             { id: 'visualizer', label: t('visualizer'), icon: <Palette size={14} /> }
           ].map(tab => (
             <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as any)}
                className={`flex items-center gap-2 px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  activeSubTab === tab.id ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
             >
                {tab.icon} {tab.label}
             </button>
           ))}
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        {activeSubTab === 'lore' && (
          <LoreSection lore={project.worldBuilding.lore} onAdd={addLore} onUpdate={updateLore} onDelete={deleteLore} t={t} />
        )}
        {activeSubTab === 'maps' && (
          <MapCreator maps={project.worldBuilding.maps} onAdd={addMap} onUpdate={updateMap} onDelete={deleteMap} t={t} />
        )}
        {activeSubTab === 'visualizer' && (
          <Visualizer characters={project.characters} onUpdateCharacter={updateCharacter} t={t} />
        )}
      </div>
    </div>
  );
};

export default WorldBuilding;
