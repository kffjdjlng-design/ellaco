
import React, { useState } from 'react';
import { Board, ProjectState } from '../types';
import { Plus, MoreHorizontal, Layout, Columns, Trash2, Edit3, X } from 'lucide-react';

interface BoardViewProps {
  boards: Board[];
  updateProject: (updates: Partial<ProjectState>) => void;
  t: (key: string) => string;
}

const BoardView: React.FC<BoardViewProps> = ({ boards, updateProject, t }) => {
  const [activeBoardId, setActiveBoardId] = useState<string>(boards[0]?.id || '');
  const activeBoard = boards.find(b => b.id === activeBoardId);

  const addBoard = () => {
    const newBoard: Board = {
      id: `board-${Date.now()}`,
      name: t('newPano'),
      columns: [
        { id: `col-${Date.now()}-1`, title: 'Brainstorm', cards: [] },
        { id: `col-${Date.now()}-2`, title: 'In Progress', cards: [] },
        { id: `col-${Date.now()}-3`, title: 'Done', cards: [] }
      ]
    };
    updateProject({ boards: [...boards, newBoard] });
    setActiveBoardId(newBoard.id);
  };

  const addCard = (colId: string) => {
    if (!activeBoard) return;
    const updatedColumns = activeBoard.columns.map(col => {
      if (col.id === colId) {
        return {
          ...col,
          cards: [...col.cards, { id: `card-${Date.now()}`, title: 'New Idea', content: 'Double click to edit...' }]
        };
      }
      return col;
    });
    updateProject({
      boards: boards.map(b => b.id === activeBoardId ? { ...b, columns: updatedColumns } : b)
    });
  };

  return (
    <div className="h-full flex flex-col gap-6 fade-in overflow-hidden">
      <div className="flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
           <div className="p-3 bg-indigo-600 text-white rounded-2xl shadow-lg shadow-indigo-100">
              <Layout size={24} />
           </div>
           <div>
              <h2 className="text-2xl font-bold text-slate-800">{t('boards')}</h2>
              <p className="text-xs text-slate-500 font-medium">{t('flexiblePlanning')}</p>
           </div>
        </div>
        <div className="flex bg-slate-200/50 p-1 rounded-2xl overflow-x-auto no-scrollbar max-w-lg">
           {boards.map(board => (
             <button
                key={board.id}
                onClick={() => setActiveBoardId(board.id)}
                className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                  activeBoardId === board.id ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                }`}
             >
                {board.name}
             </button>
           ))}
           <button onClick={addBoard} className="p-2 text-indigo-600 hover:bg-white/50 rounded-xl transition" title={t('newPano')}><Plus size={16} /></button>
        </div>
      </div>

      <div className="flex-1 overflow-x-auto pb-4 custom-scrollbar">
        {activeBoard ? (
          <div className="flex gap-6 h-full min-w-max">
            {activeBoard.columns.map(col => (
              <div key={col.id} className="w-80 flex flex-col gap-4">
                <div className="flex items-center justify-between px-2">
                  <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest">{col.title} ({col.cards.length})</h3>
                  <button className="p-1 hover:bg-slate-200 rounded transition text-slate-400"><MoreHorizontal size={14} /></button>
                </div>
                <div className="flex-1 overflow-y-auto space-y-3 p-1">
                  {col.cards.map(card => (
                    <div key={card.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition cursor-pointer group relative overflow-hidden">
                       <div className="absolute top-0 left-0 w-1 h-full bg-indigo-200 group-hover:bg-indigo-600 transition"></div>
                       <h4 className="text-xs font-bold text-slate-800 mb-2">{card.title}</h4>
                       <p className="text-[10px] text-slate-500 line-clamp-3 leading-relaxed">{card.content}</p>
                       <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition flex gap-1">
                          <button className="p-1 bg-white border border-slate-100 rounded text-slate-400 hover:text-indigo-600"><Edit3 size={10} /></button>
                       </div>
                    </div>
                  ))}
                  <button 
                    onClick={() => addCard(col.id)}
                    className="w-full py-3 border-2 border-dashed border-slate-200 rounded-xl text-slate-300 hover:border-indigo-300 hover:text-indigo-500 transition-all flex items-center justify-center gap-2 text-xs font-bold"
                  >
                    <Plus size={14} /> {t('addCard')}
                  </button>
                </div>
              </div>
            ))}
            <button className="w-80 h-12 shrink-0 border-2 border-dashed border-slate-200 rounded-xl text-slate-400 font-bold text-xs hover:border-indigo-300 hover:text-indigo-500 transition flex items-center justify-center gap-2">
              <Plus size={14} /> {t('newColumn')}
            </button>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center space-y-4">
            <Layout size={48} className="opacity-20" />
            <p className="text-xs font-bold uppercase tracking-widest">{t('boardPlaceholder')}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BoardView;
