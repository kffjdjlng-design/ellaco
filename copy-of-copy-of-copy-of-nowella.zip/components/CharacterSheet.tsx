
import React, { useState } from 'react';
import { CharacterProfile, LocationProfile, StoryItem } from '../types';
import { Edit3, Plus, UserCircle2, MapPin, Package, Search } from 'lucide-react';

interface CharacterSheetProps {
  characters: CharacterProfile[];
  locations: LocationProfile[];
  items: StoryItem[];
  t: (key: string) => string;
}

const CharacterSheet: React.FC<CharacterSheetProps> = ({ characters, locations, items, t }) => {
  const [activeTab, setActiveTab] = useState<'characters' | 'locations' | 'items'>('characters');

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 tracking-tight">{t('projectCastAssets')}</h2>
          <p className="text-sm text-slate-500 mt-1">{t('aiIdleDesc')}</p>
        </div>
        <div className="flex bg-slate-200/50 p-1 rounded-xl">
           {(['characters', 'locations', 'items'] as const).map(tab => (
             <button 
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition ${activeTab === tab ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
             >
                {t(tab === 'characters' ? 'cast' : tab)}
             </button>
           ))}
        </div>
      </div>

      {activeTab === 'characters' && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          {characters.map(char => (
            <div key={char.id} className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm hover:shadow-xl transition-all group">
              <div className="flex gap-8">
                <div className="relative shrink-0">
                   <img src={char.imageUrl || 'https://picsum.photos/seed/placeholder/400/400'} className="w-40 h-40 rounded-2xl object-cover shadow-lg group-hover:scale-105 transition-transform duration-500" alt={char.name} />
                   <button className="absolute -bottom-2 -right-2 p-2 bg-white rounded-xl shadow-lg border border-slate-100 text-slate-400 hover:text-indigo-600 transition">
                      <Edit3 size={16} />
                   </button>
                </div>
                <div className="flex-1 space-y-4">
                  <div className="flex justify-between items-start">
                     <div>
                       <h3 className="text-2xl font-bold text-slate-800">{char.name}</h3>
                       <span className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-500">{char.role}</span>
                     </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                      {char.traits.map((trait, idx) => (
                        <span key={idx} className="px-2 py-0.5 bg-slate-100 text-slate-500 rounded text-[10px] font-bold">
                          {trait}
                        </span>
                      ))}
                  </div>
                  <div className="space-y-3">
                     <div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">{t('goal')}</div>
                        <p className="text-sm text-slate-600 italic">"{char.goals}"</p>
                     </div>
                  </div>
                  <div className="flex gap-2 pt-2">
                     <button className="flex-1 py-2 bg-slate-50 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-100 transition">{t('bio')}</button>
                     <button className="flex-1 py-2 bg-indigo-50 text-indigo-600 rounded-xl text-xs font-bold hover:bg-indigo-100 transition">{t('arc')}</button>
                  </div>
                </div>
              </div>
            </div>
          ))}
          <button className="border-2 border-dashed border-slate-200 rounded-3xl p-8 flex flex-col items-center justify-center text-slate-400 hover:border-indigo-300 hover:text-indigo-500 transition group h-64">
             <UserCircle2 size={48} className="text-slate-200 group-hover:scale-110 transition mb-4" />
             <p className="text-xs font-bold uppercase tracking-widest">{t('addCharacter')}</p>
          </button>
        </div>
      )}

      {activeTab === 'locations' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
           {locations.map(loc => (
             <div key={loc.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition">
                <div className="flex items-start justify-between mb-4">
                   <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
                      <MapPin size={24} />
                   </div>
                   <button className="p-2 text-slate-300 hover:text-indigo-500"><Edit3 size={14} /></button>
                </div>
                <h3 className="font-bold text-slate-800 mb-2">{loc.name}</h3>
                <p className="text-xs text-slate-500 leading-relaxed line-clamp-3">{loc.description}</p>
             </div>
           ))}
           <button className="border-2 border-dashed border-slate-200 rounded-2xl p-6 flex flex-col items-center justify-center text-slate-400 hover:border-indigo-300 hover:text-indigo-500 transition h-40">
             <Plus size={24} className="mb-2" />
             <span className="text-[10px] font-bold uppercase tracking-widest">{t('addSetting')}</span>
          </button>
        </div>
      )}

      {activeTab === 'items' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
           {items.map(item => (
             <div key={item.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition">
                <div className="flex items-start justify-between mb-4">
                   <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                      <Package size={24} />
                   </div>
                   {item.isMacGuffin && <span className="text-[8px] font-black bg-amber-500 text-white px-2 py-1 rounded-full uppercase">MacGuffin</span>}
                </div>
                <h3 className="font-bold text-slate-800 mb-2">{item.name}</h3>
                <p className="text-xs text-slate-500 leading-relaxed line-clamp-3">{item.description}</p>
             </div>
           ))}
           <button className="border-2 border-dashed border-slate-200 rounded-2xl p-6 flex flex-col items-center justify-center text-slate-400 hover:border-indigo-300 hover:text-indigo-500 transition h-40">
             <Plus size={24} className="mb-2" />
             <span className="text-[10px] font-bold uppercase tracking-widest">{t('addPlotObject')}</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default CharacterSheet;
