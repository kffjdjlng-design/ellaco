
import React, { useRef, useEffect, useState } from 'react';
import { BinderItem, ProjectState } from '../types';
import { 
  Undo, Redo, Eraser, Bold, Italic, Underline, Strikethrough, Subscript, Superscript, Palette, Highlighter, 
  AlignLeft, AlignCenter, AlignRight, AlignJustify, IndentDecrease, IndentIncrease, List, ListOrdered, 
  CaseSensitive, ChevronDown, MessageSquarePlus, MicOff, Mic, Settings as SettingsIcon, Maximize2,
  FileText, ArrowRight, Minimize2, Sparkles, Clock, ArrowLeft
} from 'lucide-react';

interface EditorProps {
  item: BinderItem;
  onContentChange: (content: string) => void;
  onUpdateMetadata?: (updates: Partial<BinderItem>) => void;
  isCompositionMode: boolean;
  setIsCompositionMode: (val: boolean) => void;
  typewriterMode?: boolean;
  markupMode?: boolean;
  settings: ProjectState['settings'];
  onUpdateSettings: (s: Partial<ProjectState['settings']>) => void;
  t: (key: string) => string;
}

const Editor: React.FC<EditorProps> = ({ 
    item, onContentChange, onUpdateMetadata, isCompositionMode, setIsCompositionMode, typewriterMode, settings, onUpdateSettings, t
}) => {
  const editorRef = useRef<HTMLDivElement>(null);
  const isFolder = item.type === 'folder' || item.type === 'front-matter' || item.type === 'back-matter';

  useEffect(() => {
    if (editorRef.current && !isFolder && editorRef.current.innerHTML !== item.content) {
      editorRef.current.innerHTML = item.content;
    }
  }, [item.id, isFolder]);

  // Handle Escape key to exit composition mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isCompositionMode) {
        setIsCompositionMode(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCompositionMode, setIsCompositionMode]);

  const handleInput = () => {
    if (editorRef.current && !isFolder) {
      onContentChange(editorRef.current.innerHTML);
    }
  };

  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    handleInput();
  };

  const wordCount = (item.content || '').replace(/<[^>]*>/g, '').split(/\s+/).filter(x => x.length > 0).length;

  if (isFolder) {
    return (
      <div className="flex-1 overflow-y-auto bg-slate-50 p-12">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="space-y-2">
            <h1 className="text-4xl font-black text-slate-800 tracking-tight flex items-center gap-3">
              <span className="text-indigo-600 opacity-30">#</span> {item.title}
            </h1>
            <p className="text-slate-400 text-sm font-bold uppercase tracking-widest">{t('sectionOverview')} ({t('scriveningsMode')})</p>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            {item.children?.map((child, idx) => (
              <div key={child.id} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm group hover:border-indigo-400 transition cursor-pointer">
                <div className="flex justify-between items-center mb-4">
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-black text-slate-300">{idx + 1 < 10 ? `0${idx + 1}` : idx + 1}</span>
                    <h3 className="font-bold text-slate-700">{child.title}</h3>
                  </div>
                  <ArrowRight size={14} className="text-slate-300 group-hover:text-indigo-600 transition" />
                </div>
                <p className="text-xs text-slate-500 italic leading-relaxed">
                  {child.synopsis || t('aiIdleDesc')}
                </p>
                <div className="mt-4 pt-4 border-t border-slate-50 flex justify-between items-center text-[9px] font-black uppercase text-slate-400">
                  <span>{(child.content || '').replace(/<[^>]*>/g, '').split(/\s+/).filter(x => x.length > 0).length} {t('words').toLowerCase()}</span>
                  <span>{child.metadata?.status ? t(child.metadata.status.toLowerCase().replace(' ', '')) : t('todo')}</span>
                </div>
              </div>
            ))}
            {!item.children?.length && (
              <div className="py-20 text-center border-4 border-dashed border-slate-200 rounded-3xl text-slate-300 font-bold uppercase tracking-widest">
                {t('emptySection')}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex h-full editor-bg relative transition-all duration-500 ${isCompositionMode ? 'fixed inset-0 z-[200] bg-slate-50 overflow-hidden' : 'rounded-xl shadow-sm border border-slate-200 overflow-hidden'}`}>
      
      {/* Composition Mode Floating HUD - Refined with "Go Back" logic */}
      {isCompositionMode && (
        <div className="absolute top-6 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-white/90 backdrop-blur-2xl border border-slate-200/50 shadow-[0_20px_50px_rgba(0,0,0,0.1)] rounded-[20px] px-5 py-3 animate-in slide-in-from-top-6 duration-700 z-50">
          <button 
            onClick={() => setIsCompositionMode(false)}
            className="flex items-center gap-2 pr-4 border-r border-slate-200 group hover:text-indigo-600 transition-colors"
            title="Back to Studio (Esc)"
          >
             <div className="w-9 h-9 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600 group-hover:bg-indigo-600 group-hover:text-white transition-all shadow-sm">
                <ArrowLeft size={18} />
             </div>
             <div className="text-left">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{t('exit')}</p>
                <p className="text-[11px] font-bold text-slate-800">{t('studio')}</p>
             </div>
          </button>
          
          <div className="flex items-center gap-3 px-2">
             <div className="w-8 h-8 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center">
                <FileText size={16} />
             </div>
             <div className="max-w-[200px]">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">{t('writing')}</p>
                <p className="text-xs font-bold text-slate-800 truncate">{item.title}</p>
             </div>
          </div>
          
          <div className="flex items-center gap-5 px-4 py-1.5 bg-slate-50 rounded-xl border border-slate-100">
             <div className="text-center">
                <p className="text-[11px] font-black text-slate-800">{wordCount.toLocaleString()}</p>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">{t('words')}</p>
             </div>
             <div className="w-px h-4 bg-slate-200"></div>
             <div className="text-center">
                <p className="text-[11px] font-black text-slate-800">{Math.ceil(wordCount / 250)}m</p>
                <p className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">{t('time')}</p>
             </div>
          </div>

          <div className="pl-2">
             <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.5)]" title={t('autoSaved')}></div>
          </div>
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        {!isCompositionMode && (
          <div className="border-b border-slate-200 p-2 flex flex-wrap items-center gap-2 sticky top-0 bg-white z-40">
            <div className="flex items-center gap-0.5 bg-slate-100/50 p-1 rounded-lg">
              <button onClick={() => execCommand('undo')} className="p-1.5 hover:bg-white rounded transition text-slate-400" aria-label="Undo"><Undo size={14} /></button>
              <button onClick={() => execCommand('redo')} className="p-1.5 hover:bg-white rounded transition text-slate-400" aria-label="Redo"><Redo size={14} /></button>
              <button onClick={() => execCommand('removeFormat')} className="p-1.5 hover:bg-white rounded transition text-slate-400" aria-label="Clear formatting"><Eraser size={14} /></button>
            </div>
            <div className="flex items-center gap-0.5 bg-slate-100/50 p-1 rounded-lg">
              <button onClick={() => execCommand('bold')} className="p-1.5 hover:bg-white rounded transition text-slate-600" aria-label="Bold"><Bold size={14} /></button>
              <button onClick={() => execCommand('italic')} className="p-1.5 hover:bg-white rounded transition text-slate-600" aria-label="Italic"><Italic size={14} /></button>
              <button onClick={() => execCommand('underline')} className="p-1.5 hover:bg-white rounded transition text-slate-600" aria-label="Underline"><Underline size={14} /></button>
            </div>
            <button onClick={() => setIsCompositionMode(true)} className="ml-auto p-2 hover:bg-slate-100 rounded-full transition text-slate-400" aria-label="Maximize"><Maximize2 size={18} /></button>
          </div>
        )}

        <div className={`flex-1 overflow-y-auto custom-scrollbar transition-all duration-1000 ${isCompositionMode ? 'p-0 pt-32 pb-32' : 'p-12'} ${typewriterMode ? 'typewriter-active' : ''}`}>
          <div className={`max-w-3xl mx-auto bg-white transition-all duration-1000 ${isCompositionMode ? 'shadow-[0_40px_100px_rgba(0,0,0,0.08)] rounded-[60px] p-24 min-h-[120vh] mb-40 border border-slate-100' : 'shadow-sm border border-slate-100 min-h-screen p-16'}`}>
            <input 
              value={item.title}
              onChange={(e) => onUpdateMetadata?.({ title: e.target.value })}
              className={`font-bold mb-14 text-slate-800 tracking-tight leading-tight w-full bg-transparent border-none outline-none focus:ring-0 transition-all duration-1000 ${isCompositionMode ? 'text-6xl text-center' : 'text-4xl'}`}
              placeholder={t('sceneTitle') + "..."}
            />
            <div
              ref={editorRef}
              contentEditable
              onInput={handleInput}
              className={`editor-content serif text-slate-700 outline-none leading-[1.8] transition-all duration-1000 ${isCompositionMode ? 'text-2xl' : 'text-xl'}`}
              spellCheck="true"
            />
            
            {isCompositionMode && (
                <div className="mt-40 pt-16 border-t border-slate-100 flex flex-col items-center gap-4 opacity-10 hover:opacity-50 transition-opacity duration-1000">
                    <Sparkles size={24} className="text-indigo-600" />
                    <span className="text-[11px] font-black uppercase tracking-[0.5em] text-slate-400">Deep Focus Engine</span>
                    <p className="text-[9px] font-bold text-slate-300">Press ESC to return to workspace</p>
                </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Editor;
