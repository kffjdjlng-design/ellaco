
import React from 'react';
import { ProjectState, BinderItem } from '../types';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, Cell, LineChart, Line } from 'recharts';
import { 
  Trophy, Target, Calendar, Clock, FileText, Users, ArrowRight, Zap, 
  TrendingUp, Star, LayoutGrid, History, BookOpen 
} from 'lucide-react';

interface DashboardProps {
  project: ProjectState;
  onSelectScene: (id: string) => void;
  setViewMode: (mode: any) => void;
  t: (key: string) => string;
}

const Dashboard: React.FC<DashboardProps> = ({ project, onSelectScene, setViewMode, t }) => {
  // Word count calc
  const countWords = (items: BinderItem[]): number => {
    return items.reduce((acc, item) => {
      let count = (item.content || '').replace(/<[^>]*>/g, '').split(/\s+/).filter(x => x.length > 0).length;
      if (item.children) count += countWords(item.children);
      return acc + count;
    }, 0);
  };

  const totalWords = countWords(project.binder);
  const progress = Math.min(100, Math.round((totalWords / project.goals.totalWordGoal) * 100));

  // Recent scenes (flatten and sort by lastEdited)
  const getFlattenedScenes = (items: BinderItem[]): BinderItem[] => {
    let scenes: BinderItem[] = [];
    items.forEach(i => {
      if (i.type === 'document') scenes.push(i);
      if (i.children) scenes = [...scenes, ...getFlattenedScenes(i.children)];
    });
    return scenes;
  };

  const recentScenes = getFlattenedScenes(project.binder)
    .sort((a, b) => (b.metadata?.lastEdited || 0) - (a.metadata?.lastEdited || 0))
    .slice(0, 4);

  // Stats data
  const chartData = project.writingLog.slice(-7).map(log => ({
    date: new Date(log.timestamp).toLocaleDateString(undefined, { weekday: 'short' }),
    words: log.wordsAdded
  }));

  // Velocity Calculation
  const avgVelocity = project.writingLog.length > 0 
    ? Math.round(project.writingLog.reduce((acc, l) => acc + l.wordsAdded, 0) / project.writingLog.length) 
    : 0;

  return (
    <div className="h-full overflow-y-auto bg-slate-50 custom-scrollbar animate-in fade-in duration-700">
      <div className="max-w-7xl mx-auto p-6 md:p-12 space-y-10 pb-24">
        
        {/* Hero Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white rounded-[40px] p-10 border border-slate-200 shadow-sm relative overflow-hidden group hover:shadow-xl transition-all duration-500">
             <div className="absolute top-0 right-0 p-12 opacity-5 -mr-10 -mt-10 group-hover:scale-110 transition-transform duration-1000">
                <Trophy size={300} />
             </div>
             
             <div className="relative z-10 space-y-8">
                <div className="flex items-center gap-4">
                   <div className="w-16 h-16 bg-indigo-600 rounded-3xl flex items-center justify-center text-white shadow-2xl shadow-indigo-200">
                      <BookOpen size={32} />
                   </div>
                   <div>
                      <h1 className="text-4xl font-black text-slate-800 tracking-tight">{project.name}</h1>
                      <p className="text-slate-500 font-medium">by {project.authorName || 'Professional Author'}</p>
                   </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-10">
                   <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('totalManuscriptProgress')}</p>
                      <div className="flex items-baseline gap-2">
                         <span className="text-4xl font-black text-slate-800">{progress}%</span>
                         <span className="text-xs font-bold text-emerald-500 flex items-center gap-1">
                            <TrendingUp size={12} /> +2.4%
                         </span>
                      </div>
                      <div className="w-full h-2 bg-slate-100 rounded-full mt-4 overflow-hidden">
                         <div className="h-full bg-indigo-600 rounded-full transition-all duration-1000" style={{ width: `${progress}%` }}></div>
                      </div>
                   </div>

                   <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('words')}</p>
                      <div className="flex items-baseline gap-1">
                         <span className="text-4xl font-black text-slate-800">{totalWords.toLocaleString()}</span>
                         <span className="text-[10px] font-bold text-slate-400">/ {project.goals.totalWordGoal.toLocaleString()}</span>
                      </div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase mt-4 tracking-tighter">Target: {project.goals.dailyWordGoal} per day</p>
                   </div>

                   <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('writingVelocity')}</p>
                      <div className="flex items-baseline gap-1">
                         <span className="text-4xl font-black text-indigo-600">{avgVelocity}</span>
                         <span className="text-[10px] font-bold text-slate-400">w/session</span>
                      </div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase mt-4 tracking-tighter">{project.writingLog.length} sessions logged</p>
                   </div>
                </div>
             </div>
          </div>

          <div className="bg-slate-900 rounded-[40px] p-8 text-white flex flex-col justify-between shadow-2xl shadow-indigo-100 relative overflow-hidden group">
             <div className="absolute inset-0 bg-indigo-600/10 group-hover:bg-indigo-600/20 transition-colors"></div>
             <div className="relative z-10 space-y-6">
                <div className="flex items-center justify-between">
                   <h3 className="text-[10px] font-black uppercase tracking-[0.3em] opacity-50">{t('deadlineInsight')}</h3>
                   <Calendar size={18} className="opacity-50" />
                </div>
                <div>
                   <p className="text-5xl font-black tracking-tighter">42</p>
                   <p className="text-xs font-bold opacity-60 uppercase tracking-widest mt-1">{t('daysLeft')}</p>
                </div>
                <div className="p-4 bg-white/10 rounded-2xl backdrop-blur-md border border-white/10 space-y-2">
                   <p className="text-[10px] font-black uppercase tracking-widest opacity-50">{t('writingTime')}</p>
                   <div className="flex items-center gap-2">
                      <Zap size={14} className="text-amber-400" />
                      <span className="text-sm font-bold">14h 20m this week</span>
                   </div>
                </div>
             </div>
             <button 
               onClick={() => setViewMode('log')}
               className="relative z-10 w-full py-4 bg-white text-slate-900 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-50 transition-colors mt-8"
             >
                {t('sessionHistory')}
             </button>
          </div>
        </div>

        {/* Bottom Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          
          {/* Quick Access Documents */}
          <div className="bg-white rounded-[32px] p-8 border border-slate-200 shadow-sm space-y-6">
             <div className="flex justify-between items-center">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
                  <History size={16} className="text-indigo-600" /> {t('history')}
                </h3>
                <button 
                  onClick={() => setViewMode('editor')}
                  className="text-[10px] font-black text-indigo-600 uppercase hover:underline"
                >
                  {t('studio')}
                </button>
             </div>
             <div className="space-y-3">
                {recentScenes.map(scene => (
                   <button 
                    key={scene.id}
                    onClick={() => onSelectScene(scene.id)}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl border border-slate-50 hover:border-indigo-200 hover:bg-indigo-50/50 transition-all group"
                   >
                      <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-white group-hover:text-indigo-600 transition-all">
                         <FileText size={18} />
                      </div>
                      <div className="flex-1 text-left min-w-0">
                         <p className="text-sm font-bold text-slate-700 truncate">{scene.title}</p>
                         <p className="text-[9px] font-bold text-slate-400 uppercase">{t(scene.metadata?.status?.toLowerCase() || 'todo')}</p>
                      </div>
                      <ArrowRight size={14} className="text-slate-300 group-hover:translate-x-1 transition-all" />
                   </button>
                ))}
             </div>
          </div>

          {/* Cast Overview */}
          <div className="bg-white rounded-[32px] p-8 border border-slate-200 shadow-sm space-y-6">
             <div className="flex justify-between items-center">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
                  <Users size={16} className="text-indigo-600" /> {t('cast')}
                </h3>
                <button 
                  onClick={() => setViewMode('characters')}
                  className="text-[10px] font-black text-indigo-600 uppercase hover:underline"
                >
                  {t('view')}
                </button>
             </div>
             <div className="grid grid-cols-2 gap-4">
                {project.characters.slice(0, 4).map(char => (
                   <div key={char.id} className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col items-center text-center space-y-2">
                      <div className="w-12 h-12 rounded-full border-2 border-white shadow-sm overflow-hidden bg-slate-200">
                         <img src={char.imageUrl || `https://picsum.photos/seed/${char.id}/100/100`} className="w-full h-full object-cover" alt="" />
                      </div>
                      <div>
                         <p className="text-[11px] font-black text-slate-700 truncate w-full px-1">{char.name}</p>
                         <p className="text-[8px] font-bold text-slate-400 uppercase truncate w-full">{char.role}</p>
                      </div>
                   </div>
                ))}
                <button 
                  onClick={() => setViewMode('characters')}
                  className="bg-indigo-50 p-4 rounded-2xl border border-dashed border-indigo-200 flex flex-col items-center justify-center text-indigo-600 hover:bg-indigo-100 transition-colors"
                >
                   <Plus size={20} className="mb-1" />
                   <span className="text-[8px] font-black uppercase">{t('addCharacter')}</span>
                </button>
             </div>
          </div>

          {/* Productivity Chart */}
          <div className="bg-white rounded-[32px] p-8 border border-slate-200 shadow-sm space-y-6 flex flex-col">
             <div className="flex justify-between items-center">
                <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-2">
                  <TrendingUp size={16} className="text-indigo-600" /> {t('writingVelocity')}
                </h3>
             </div>
             <div className="flex-1 min-h-[200px] w-full bg-slate-50/50 rounded-2xl p-4 border border-slate-100">
                <ResponsiveContainer width="100%" height="100%">
                   <BarChart data={chartData}>
                      <Tooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontSize: '10px', fontWeight: 'bold' }}
                        cursor={{ fill: 'transparent' }}
                      />
                      <Bar dataKey="words" radius={[6, 6, 0, 0]}>
                         {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.words > avgVelocity ? '#4f46e5' : '#cbd5e1'} />
                         ))}
                      </Bar>
                   </BarChart>
                </ResponsiveContainer>
             </div>
             <div className="flex justify-between items-center pt-2">
                <div className="flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full bg-indigo-600"></div>
                   <span className="text-[9px] font-bold text-slate-400 uppercase">Above Avg</span>
                </div>
                <div className="flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full bg-slate-300"></div>
                   <span className="text-[9px] font-bold text-slate-400 uppercase">Below Avg</span>
                </div>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};

const Plus: React.FC<{ size?: number; className?: string }> = ({ size = 16, className = "" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
);

export default Dashboard;
