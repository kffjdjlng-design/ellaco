
import React, { useState } from 'react';
import { ViewMode, Language } from '../types';
import { Layout, List, FileText, Users, Split, PanelRightOpen, PanelRightClose, Settings, Share2, Download, Archive, Type, Layers, History, BookOpen, Globe, ChevronDown, Check, Compass, Palette, ChevronLeft, ChevronRight, RefreshCw, Plus } from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '../constants';

interface HeaderProps {
  projectName: string;
  projectLanguage: Language;
  uiLanguage: Language;
  setProjectLanguage: (l: Language) => void;
  setUILanguage: (l: Language) => void;
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  isCompositionMode: boolean;
  setIsCompositionMode: (val: boolean) => void;
  showRightPanel: boolean;
  setShowRightPanel: (val: boolean) => void;
  typewriterMode?: boolean;
  toggleTypewriter?: () => void;
  t: (key: string) => string;
  canGoBack?: boolean;
  canGoForward?: boolean;
  onGoBack?: () => void;
  onGoForward?: () => void;
  onRefresh?: () => void;
  onNewProject: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  projectName, projectLanguage, uiLanguage, setProjectLanguage, setUILanguage, viewMode, setViewMode, isCompositionMode, setIsCompositionMode, showRightPanel, setShowRightPanel,
  typewriterMode, toggleTypewriter, t, canGoBack, canGoForward, onGoBack, onGoForward, onRefresh, onNewProject
}) => {
  const [showLangMenu, setShowLangMenu] = useState<'ui' | 'project' | null>(null);

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center px-6 justify-between shrink-0 z-[100] shadow-sm">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-3 cursor-pointer group" onClick={() => setViewMode('editor')}>
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold shadow-indigo-200 shadow-lg group-hover:bg-slate-900 transition-all duration-300">N</div>
            <h1 className="font-black text-slate-800 tracking-tight hidden md:block">{projectName}</h1>
        </div>
        
        <div className="flex items-center gap-0.5 bg-slate-50 border border-slate-200 rounded-xl p-0.5">
          <button 
            onClick={onGoBack} 
            disabled={!canGoBack}
            className={`p-1.5 rounded-lg transition-all ${canGoBack ? 'text-slate-600 hover:bg-white hover:shadow-sm active:scale-90' : 'text-slate-200 cursor-not-allowed'}`}
          >
            <ChevronLeft size={18} />
          </button>
          <button 
            onClick={onGoForward} 
            disabled={!canGoForward}
            className={`p-1.5 rounded-lg transition-all ${canGoForward ? 'text-slate-600 hover:bg-white hover:shadow-sm active:scale-90' : 'text-slate-200 cursor-not-allowed'}`}
          >
            <ChevronRight size={18} />
          </button>
          <div className="w-px h-4 bg-slate-200 mx-0.5"></div>
          <button 
            onClick={onRefresh}
            className="p-1.5 rounded-lg text-slate-600 hover:bg-white hover:shadow-sm transition-all active:scale-90"
          >
            <RefreshCw size={16} />
          </button>
        </div>

        <button 
          onClick={onNewProject}
          className="flex items-center gap-2 px-3 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-700 transition shadow-lg shadow-indigo-100"
        >
          <Plus size={14} /> {t('startNewWork')}
        </button>

        <div className="h-6 w-px bg-slate-200 hidden md:block"></div>

        <nav className="flex items-center gap-1 bg-slate-100/80 p-1 rounded-xl">
          <button 
            onClick={() => setViewMode('editor')} 
            className={`p-2 rounded-lg flex items-center gap-2 text-[11px] font-black uppercase tracking-wider transition ${['editor', 'split'].includes(viewMode) ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <FileText size={16} /> <span className="hidden lg:inline">{t('studio')}</span>
          </button>
          <button 
            onClick={() => setViewMode('world')} 
            className={`p-2 rounded-lg flex items-center gap-2 text-[11px] font-black uppercase tracking-wider transition ${viewMode === 'world' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <Compass size={16} /> <span className="hidden lg:inline">{t('world')}</span>
          </button>
          <button 
            onClick={() => setViewMode('corkboard')} 
            className={`p-2 rounded-lg flex items-center gap-2 text-[11px] font-black uppercase tracking-wider transition ${viewMode === 'corkboard' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <Layout size={16} /> <span className="hidden lg:inline">{t('board')}</span>
          </button>
          <button 
            onClick={() => setViewMode('outliner')} 
            className={`p-2 rounded-lg flex items-center gap-2 text-[11px] font-black uppercase tracking-wider transition ${viewMode === 'outliner' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <List size={16} /> <span className="hidden lg:inline">{t('outline')}</span>
          </button>
          <button 
            onClick={() => setViewMode('characters')} 
            className={`p-2 rounded-lg flex items-center gap-2 text-[11px] font-black uppercase tracking-wider transition ${viewMode === 'characters' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}
          >
            <Users size={16} /> <span className="hidden lg:inline">{t('cast')}</span>
          </button>
        </nav>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          {/* UI Language Select */}
          <div className="relative">
            <button 
              onClick={() => setShowLangMenu(showLangMenu === 'ui' ? null : 'ui')}
              className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 rounded-xl text-[9px] font-black uppercase tracking-widest text-slate-600 transition border border-slate-200"
              title={t('appLanguage')}
            >
              <Palette size={12} className="text-indigo-500" />
              <span className="hidden sm:inline">{SUPPORTED_LANGUAGES.find(l => l.name === uiLanguage)?.label}</span>
              <ChevronDown size={10} />
            </button>
            {showLangMenu === 'ui' && (
              <div className="absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-2xl shadow-2xl p-2 z-[110] animate-in fade-in zoom-in-95 duration-200">
                <p className="px-3 py-1.5 text-[8px] font-black uppercase text-slate-400 tracking-[0.2em]">{t('appLanguage')}</p>
                 {SUPPORTED_LANGUAGES.map(lang => (
                   <button 
                    key={lang.name}
                    onClick={() => {
                      setUILanguage(lang.name);
                      setShowLangMenu(null);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center justify-between group ${uiLanguage === lang.name ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-50'}`}
                   >
                     <span>{lang.label}</span>
                     {uiLanguage === lang.name && <Check size={12} />}
                   </button>
                 ))}
              </div>
            )}
          </div>

          {/* Project Language Select */}
          <div className="relative">
            <button 
              onClick={() => setShowLangMenu(showLangMenu === 'project' ? null : 'project')}
              className="flex items-center gap-2 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 rounded-xl text-[9px] font-black uppercase tracking-widest text-indigo-600 transition border border-indigo-100"
              title={t('projectLanguage')}
            >
              <Globe size={12} />
              <span className="hidden sm:inline">{SUPPORTED_LANGUAGES.find(l => l.name === projectLanguage)?.label}</span>
              <ChevronDown size={10} />
            </button>
            {showLangMenu === 'project' && (
              <div className="absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-2xl shadow-2xl p-2 z-[110] animate-in fade-in zoom-in-95 duration-200">
                <p className="px-3 py-1.5 text-[8px] font-black uppercase text-slate-400 tracking-[0.2em]">{t('projectLanguage')}</p>
                 {SUPPORTED_LANGUAGES.map(lang => (
                   <button 
                    key={lang.name}
                    onClick={() => {
                      setProjectLanguage(lang.name);
                      setShowLangMenu(null);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center justify-between group ${projectLanguage === lang.name ? 'bg-indigo-50 text-indigo-600' : 'text-slate-600 hover:bg-slate-50'}`}
                   >
                     <span>{lang.label}</span>
                     {projectLanguage === lang.name && <Check size={12} />}
                   </button>
                 ))}
              </div>
            )}
          </div>
        </div>

        <button 
          onClick={() => setViewMode('reader')} 
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition border ${viewMode === 'reader' ? 'bg-slate-900 text-white border-slate-900' : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'}`}
        >
            <BookOpen size={16} /> <span className="hidden lg:inline">{t('reader')}</span>
        </button>

        <button 
          onClick={() => setViewMode('compile')} 
          className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition shadow-lg ${viewMode === 'compile' ? 'bg-indigo-600 text-white' : 'bg-indigo-50 text-indigo-600 hover:bg-indigo-100 shadow-indigo-50'}`}
        >
            <Archive size={16} /> <span className="hidden sm:inline">{t('produce')}</span>
        </button>

        <div className="h-6 w-px bg-slate-200 hidden sm:block"></div>

        <div className="flex items-center gap-1">
            <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition" title={t('compile')}><Download size={18} /></button>
            <button onClick={() => setShowRightPanel(!showRightPanel)} className={`p-2 transition rounded-lg ${showRightPanel ? 'text-indigo-600 bg-indigo-50' : 'text-slate-400 hover:bg-slate-50'}`} title={t('inspector')}>
                {showRightPanel ? <PanelRightClose size={20} /> : <PanelRightOpen size={20} />}
            </button>
        </div>
      </div>
      {showLangMenu && <div className="fixed inset-0 z-[90]" onClick={() => setShowLangMenu(null)}></div>}
    </header>
  );
};

export default Header;
