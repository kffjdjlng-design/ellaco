
import React from 'react';
import { BinderItem, Storyline } from '../types';
import { Search, Filter, MoreHorizontal, Flame, Target, Clock, Flag } from 'lucide-react';

interface OutlinerProps {
  folder: BinderItem;
  storylines?: Storyline[];
  onUpdateItem: (id: string, updates: Partial<BinderItem>) => void;
  t: (key: string) => string;
}

const Outliner: React.FC<OutlinerProps> = ({ folder, storylines = [], onUpdateItem, t }) => {
  const items = folder.children || [];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full fade-in">
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
        <div className="flex items-center gap-4">
          <div className="relative">
             <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
             <input type="text" placeholder={t('filterScenes')} className="pl-9 pr-4 py-1.5 bg-white border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none w-64" />
          </div>
          <button className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-slate-600 border border-slate-200 rounded-lg hover:bg-white transition bg-white/50">
             <Filter size={14} /> {t('viewOptions')}
          </button>
        </div>
        <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-100 px-3 py-1.5 rounded-lg">
                {t('words')}: {items.reduce((acc, i) => acc + (i.content || '').replace(/<[^>]*>/g, '').split(/\s+/).filter(x => x.length > 0).length, 0).toLocaleString()}
            </span>
            <button className="p-2 hover:bg-slate-200 rounded-lg transition text-slate-400">
                <MoreHorizontal size={18} />
            </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse table-fixed">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-100 sticky top-0 z-10">
              <th className="w-12 px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">#</th>
              <th className="w-48 px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('sceneTitle')}</th>
              <th className="w-24 px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('status')}</th>
              <th className="w-24 px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('plotThread')}</th>
              <th className="w-24 px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-center">{t('tension')}</th>
              <th className="w-32 px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('timeDay')}</th>
              <th className="w-32 px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('conflict')}</th>
              <th className="w-24 px-4 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">{t('words')}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.map((item, idx) => {
                const yData = item.yWriterData || {};
                const storyline = storylines.find(s => s.id === yData.storylineId);
                const wordCount = (item.content || '').replace(/<[^>]*>/g, '').split(/\s+/).filter(x => x.length > 0).length;
                
                return (
                    <tr key={item.id} className="hover:bg-slate-50/50 transition cursor-default group">
                        <td className="px-4 py-4 text-center">
                            <span className="text-[10px] font-black text-slate-300">{idx + 1}</span>
                        </td>
                        <td className="px-4 py-4">
                            <span className="text-sm font-semibold text-slate-700 truncate block">{item.title}</span>
                        </td>
                        <td className="px-4 py-4">
                            <div className={`inline-block text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md ${
                                item.metadata?.status === 'Final' ? 'bg-emerald-100 text-emerald-700' :
                                item.metadata?.status === 'Revised' ? 'bg-indigo-100 text-indigo-700' :
                                item.metadata?.status === 'First Draft' ? 'bg-amber-100 text-amber-700' :
                                'bg-slate-100 text-slate-600'
                            }`}>
                                {item.metadata?.status || 'To Do'}
                            </div>
                        </td>
                        <td className="px-4 py-4">
                            {storyline ? (
                                <div className="flex items-center gap-1.5">
                                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: storyline.color }}></div>
                                    <span className="text-[10px] font-bold text-slate-500 truncate">{storyline.name}</span>
                                </div>
                            ) : <span className="text-[10px] text-slate-300 italic">{t('aiIdle')}</span>}
                        </td>
                        <td className="px-4 py-4 text-center">
                            <div className="flex items-center justify-center gap-1">
                                <Flame size={10} className={yData.tension && yData.tension > 7 ? 'text-rose-500' : 'text-slate-200'} />
                                <span className="text-[10px] font-bold text-slate-400">{yData.tension || 0}</span>
                            </div>
                        </td>
                        <td className="px-4 py-4">
                            <div className="flex flex-col">
                                <span className="text-[10px] font-bold text-slate-600">{yData.timeOfDay || '-'}</span>
                                <span className="text-[9px] font-black text-indigo-400 uppercase">{t('part')} {yData.inStoryDay || 1}</span>
                            </div>
                        </td>
                        <td className="px-4 py-4">
                            <p className="text-[10px] text-slate-500 truncate italic">{yData.conflict || '-'}</p>
                        </td>
                        <td className="px-4 py-4 text-right">
                            <span className="text-xs font-bold text-slate-600">{wordCount}</span>
                        </td>
                    </tr>
                );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Outliner;
