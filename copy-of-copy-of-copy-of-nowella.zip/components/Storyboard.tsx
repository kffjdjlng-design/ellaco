
import React from 'react';
import { BinderItem } from '../types';
import { Flame, Target, Clock, MessageSquare } from 'lucide-react';

interface StoryboardProps {
  binder: BinderItem[];
  onSelect: (id: string) => void;
  t: (key: string) => string;
}

const Storyboard: React.FC<StoryboardProps> = ({ binder, onSelect, t }) => {
  // Flatten binder to get all documents (scenes)
  const getAllScenes = (items: BinderItem[]): BinderItem[] => {
    let scenes: BinderItem[] = [];
    items.forEach(item => {
      if (item.type === 'document') scenes.push(item);
      if (item.children) scenes = [...scenes, ...getAllScenes(item.children)];
    });
    return scenes;
  };

  const scenes = getAllScenes(binder);

  return (
    <div className="h-full bg-slate-100 rounded-3xl p-8 overflow-x-auto overflow-y-hidden">
      <div className="flex gap-8 h-full min-w-max pb-12">
        {scenes.map((scene, idx) => {
          const yData = scene.yWriterData || {};
          const tension = yData.tension || 5;
          const importance = yData.importance || 5;

          return (
            <div key={scene.id} className="relative flex flex-col w-64 h-full shrink-0">
               {/* Path Indicator */}
               {idx < scenes.length - 1 && (
                  <div className="absolute top-1/2 left-full w-8 h-0.5 bg-indigo-200/50 -translate-y-1/2"></div>
               )}

               <div 
                 onClick={() => onSelect(scene.id)}
                 className="bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all cursor-pointer p-6 flex flex-col h-full group"
               >
                  <div className="flex justify-between items-start mb-4">
                      <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{t('part')} {idx + 1}</span>
                      <div className="flex gap-1">
                          <div className={`w-2 h-2 rounded-full ${tension > 7 ? 'bg-rose-500' : 'bg-slate-200'}`} title={t('tension')}></div>
                          <div className={`w-2 h-2 rounded-full ${importance > 7 ? 'bg-indigo-500' : 'bg-slate-200'}`} title={t('importance')}></div>
                      </div>
                  </div>

                  <h3 className="font-bold text-slate-800 text-sm mb-3 group-hover:text-indigo-600 truncate">{scene.title}</h3>
                  <p className="text-xs text-slate-500 leading-relaxed line-clamp-4 italic mb-4">
                      {scene.synopsis || t('aiIdleDesc')}
                  </p>

                  <div className="mt-auto space-y-4 pt-4 border-t border-slate-50">
                      <div className="flex items-center justify-between">
                         <div className="flex items-center gap-1.5">
                            <Flame size={12} className="text-rose-400" />
                            <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                <div className="h-full bg-rose-400" style={{ width: `${tension * 10}%` }}></div>
                            </div>
                         </div>
                         <span className="text-[9px] font-bold text-slate-400">{t('tension')}</span>
                      </div>

                      <div className="flex items-center justify-between">
                         <div className="flex items-center gap-1.5">
                            <Target size={12} className="text-indigo-400" />
                            <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                <div className="h-full bg-indigo-400" style={{ width: `${importance * 10}%` }}></div>
                            </div>
                         </div>
                         <span className="text-[9px] font-bold text-slate-400">{t('efficiencyScore')}</span>
                      </div>

                      <div className="flex items-center justify-between pt-2">
                         <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                             <Clock size={10} /> {yData.timeOfDay || '12:00'}
                         </span>
                         <span className="text-[10px] font-black text-indigo-500 uppercase">{t('part')} {yData.inStoryDay || 1}</span>
                      </div>
                  </div>
               </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Storyboard;
