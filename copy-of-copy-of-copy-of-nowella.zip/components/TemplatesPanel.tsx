
import React from 'react';
import { Copy, ArrowLeft, Book, Film, Scroll, FlaskConical, Newspaper, CheckCircle2, Zap, Swords, UserCheck, Star } from 'lucide-react';

interface Template {
  id: string;
  nameKey: string;
  descKey: string;
  icon: React.ReactNode;
  category: string;
  milestones: string[];
}

const TEMPLATES: Template[] = [
  { 
    id: 'novel', 
    nameKey: 'standardNovel', 
    descKey: 'aiIdleDesc', 
    icon: <Book size={32} className="text-indigo-500" />, 
    category: 'Fiction',
    milestones: ['Prologue', 'Chapters 1-30', 'Epilogue']
  },
  { 
    id: 'heros-journey', 
    nameKey: 'heroJourney', 
    descKey: 'aiIdleDesc', 
    icon: <Star size={32} className="text-amber-500" />, 
    category: 'Epic Fantasy',
    milestones: ['Call to Adventure', 'The Threshold', 'The Ordeal']
  },
  { 
    id: 'save-the-cat', 
    nameKey: 'saveTheCat', 
    descKey: 'aiIdleDesc', 
    icon: <Zap size={32} className="text-rose-500" />, 
    category: 'Screenwriting',
    milestones: ['Opening Image', 'Theme Stated', 'The B-Story']
  },
  { 
    id: 'thriller', 
    nameKey: 'thrillerPulse', 
    descKey: 'aiIdleDesc', 
    icon: <Swords size={32} className="text-slate-800" />, 
    category: 'Genre Fiction',
    milestones: ['Inciting Incident', 'The Midpoint Twist', 'Climax']
  },
  { 
    id: 'thesis', 
    nameKey: 'academicMaster', 
    descKey: 'aiIdleDesc', 
    icon: <FlaskConical size={32} className="text-emerald-500" />, 
    category: 'Non-Fiction',
    milestones: ['Literature Review', 'Methodology', 'Appendices']
  },
  { 
    id: 'biography', 
    nameKey: 'lifeLegacy', 
    descKey: 'aiIdleDesc', 
    icon: <UserCheck size={32} className="text-blue-500" />, 
    category: 'Biography',
    milestones: ['Origins', 'The Struggle', 'The Legacy']
  },
];

interface TemplatesPanelProps {
  onSelect: (t: Template) => void;
  onBack: () => void;
  t: (key: string) => string;
}

const TemplatesPanel: React.FC<TemplatesPanelProps> = ({ onSelect, onBack, t }) => {
  return (
    <div className="h-full flex flex-col bg-white rounded-[32px] overflow-hidden border border-slate-200 shadow-sm fade-in">
      <div className="p-8 md:p-10 border-b border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-6">
           <button onClick={onBack} className="p-3 bg-slate-50 hover:bg-slate-100 rounded-full transition group">
              <ArrowLeft size={24} className="text-slate-600 group-hover:-translate-x-1 transition-transform" />
           </button>
           <div>
              <h2 className="text-3xl font-black text-slate-800 tracking-tight">{t('blueprintTitle')}</h2>
              <p className="text-sm text-slate-500 font-medium">{t('blueprintDesc')}</p>
           </div>
        </div>
        <div className="flex items-center gap-3 px-5 py-2.5 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-100">
           <Copy size={14} /> {t('templates')}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8 md:p-10 custom-scrollbar">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-10">
          {TEMPLATES.map(template => (
            <div 
              key={template.id}
              onClick={() => onSelect(template)}
              className="bg-white border-2 border-slate-100 hover:border-indigo-600 rounded-[40px] p-8 space-y-6 cursor-pointer group transition-all duration-500 hover:shadow-2xl hover:-translate-y-2 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-slate-50 rounded-bl-[80px] -mr-8 -mt-8 transition-colors group-hover:bg-indigo-50"></div>
              
              <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center group-hover:bg-white group-hover:shadow-lg transition-all duration-500 relative z-10">
                {template.icon}
              </div>
              
              <div className="space-y-3 relative z-10">
                <span className="text-[10px] font-black uppercase text-indigo-400 tracking-[0.25em]">{template.category}</span>
                <h3 className="text-2xl font-black text-slate-800 tracking-tight">{t(template.nameKey)}</h3>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">{t(template.descKey)}</p>
              </div>

              <div className="space-y-2 relative z-10">
                 <div className="text-[9px] font-black text-slate-300 uppercase tracking-widest">{t('includes')}</div>
                 <div className="flex flex-wrap gap-1.5">
                    {template.milestones.map(m => (
                        <span key={m} className="px-2.5 py-1 bg-slate-50 rounded-lg text-[10px] font-bold text-slate-500 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">{m}</span>
                    ))}
                 </div>
              </div>

              <div className="pt-6 flex justify-between items-center border-t border-slate-100 relative z-10">
                 <button className="text-[10px] font-black text-indigo-600 uppercase tracking-widest group-hover:translate-x-1 transition-transform">{t('initializeFramework')}</button>
                 <CheckCircle2 size={18} className="text-slate-100 group-hover:text-indigo-600 transition-colors" />
              </div>
            </div>
          ))}
          <div className="border-4 border-dashed border-slate-100 rounded-[40px] p-8 flex flex-col items-center justify-center text-slate-300 gap-6 hover:border-indigo-200 hover:text-indigo-400 transition-all duration-500 cursor-pointer bg-slate-50/30">
            <div className="w-20 h-20 rounded-full border-4 border-dashed border-current flex items-center justify-center text-4xl font-light hover:scale-110 transition-transform">+</div>
            <div className="text-center space-y-1">
                <span className="text-xs font-black uppercase tracking-widest">{t('customArchitecture')}</span>
                <p className="text-[10px] font-medium opacity-60">{t('aiIdleDesc')}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplatesPanel;
